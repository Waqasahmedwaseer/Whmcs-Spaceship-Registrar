<?php
/**
 * Email Verification Pro for WHMCS
 *
 * A comprehensive email verification module that ensures customers verify
 * their email addresses before accessing their account or completing checkout.
 *
 * @copyright 2026
 * @license Proprietary
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

/**
 * Module Configuration
 *
 * @return array
 */
function email_verification_pro_config()
{
    return [
        'name' => 'Email Verification Pro',
        'description' => 'Require email verification for new registrations. Prevent fraud and ensure legitimate customer accounts.',
        'version' => '1.0.0',
        'author' => 'WHMCS Module Developer',
        'language' => 'english',
        'fields' => [
            'verification_type' => [
                'FriendlyName' => 'Verification Type',
                'Type' => 'dropdown',
                'Options' => [
                    'all_pages' => 'All Pages (Block entire account access)',
                    'checkout' => 'Checkout Only (Block orders until verified)',
                ],
                'Default' => 'all_pages',
                'Description' => 'Choose when to require email verification',
            ],
            'auto_terminate_enabled' => [
                'FriendlyName' => 'Enable Auto-Terminate',
                'Type' => 'yesno',
                'Default' => 'yes',
                'Description' => 'Automatically close accounts that don\'t verify within specified days',
            ],
            'auto_terminate_days' => [
                'FriendlyName' => 'Auto-Terminate After (Days)',
                'Type' => 'text',
                'Size' => '5',
                'Default' => '7',
                'Description' => 'Days before unverified accounts are closed',
            ],
            'auto_delete_enabled' => [
                'FriendlyName' => 'Enable Auto-Delete',
                'Type' => 'yesno',
                'Default' => 'no',
                'Description' => 'Permanently delete unverified accounts with no active orders',
            ],
            'auto_delete_days' => [
                'FriendlyName' => 'Auto-Delete After (Days)',
                'Type' => 'text',
                'Size' => '5',
                'Default' => '30',
                'Description' => 'Days before unverified accounts are deleted',
            ],
            'resend_reminder_days' => [
                'FriendlyName' => 'Resend Reminder After (Days)',
                'Type' => 'text',
                'Size' => '5',
                'Default' => '3',
                'Description' => 'Days before sending a verification reminder',
            ],
            'token_expiry_hours' => [
                'FriendlyName' => 'Verification Link Expiry (Hours)',
                'Type' => 'text',
                'Size' => '5',
                'Default' => '48',
                'Description' => 'Hours before verification links expire',
            ],
            'lock_email_change' => [
                'FriendlyName' => 'Lock Email Address',
                'Type' => 'yesno',
                'Default' => 'yes',
                'Description' => 'Prevent unverified users from changing their email',
            ],
            'allow_support_tickets' => [
                'FriendlyName' => 'Allow Support Tickets',
                'Type' => 'yesno',
                'Default' => 'yes',
                'Description' => 'Allow unverified users to access support tickets',
            ],
            'allow_profile_edit' => [
                'FriendlyName' => 'Allow Profile Edit',
                'Type' => 'yesno',
                'Default' => 'yes',
                'Description' => 'Allow unverified users to edit their profile',
            ],
            'captcha_type' => [
                'FriendlyName' => 'Captcha Type',
                'Type' => 'dropdown',
                'Options' => [
                    'none' => 'None',
                    'recaptcha_v3' => 'Google reCAPTCHA v3',
                    'turnstile' => 'Cloudflare Turnstile',
                ],
                'Default' => 'none',
                'Description' => 'Extra security on verification page',
            ],
            'recaptcha_site_key' => [
                'FriendlyName' => 'reCAPTCHA Site Key',
                'Type' => 'text',
                'Size' => '50',
                'Default' => '',
                'Description' => 'Google reCAPTCHA v3 site key',
            ],
            'recaptcha_secret_key' => [
                'FriendlyName' => 'reCAPTCHA Secret Key',
                'Type' => 'password',
                'Size' => '50',
                'Default' => '',
                'Description' => 'Google reCAPTCHA v3 secret key',
            ],
            'turnstile_site_key' => [
                'FriendlyName' => 'Turnstile Site Key',
                'Type' => 'text',
                'Size' => '50',
                'Default' => '',
                'Description' => 'Cloudflare Turnstile site key',
            ],
            'turnstile_secret_key' => [
                'FriendlyName' => 'Turnstile Secret Key',
                'Type' => 'password',
                'Size' => '50',
                'Default' => '',
                'Description' => 'Cloudflare Turnstile secret key',
            ],
            'send_welcome_after_verify' => [
                'FriendlyName' => 'Send Welcome Email After Verification',
                'Type' => 'yesno',
                'Default' => 'yes',
                'Description' => 'Send the WHMCS welcome email after successful verification',
            ],
            'redirect_after_verify' => [
                'FriendlyName' => 'Redirect After Verification',
                'Type' => 'dropdown',
                'Options' => [
                    'clientarea' => 'Client Area Home',
                    'cart' => 'Shopping Cart (if items present)',
                    'previous' => 'Previous Page',
                ],
                'Default' => 'clientarea',
                'Description' => 'Where to redirect after successful verification',
            ],
            'twofa_header' => [
                'FriendlyName' => '<hr><strong>Two-Factor Authentication (2FA)</strong>',
                'Type' => 'description',
                'Default' => 'Configure email-based 2FA for all login attempts.',
            ],
            'twofa_enabled' => [
                'FriendlyName' => 'Enable Login 2FA',
                'Type' => 'yesno',
                'Default' => 'no',
                'Description' => 'Require email code verification on every login',
            ],
            'twofa_code_length' => [
                'FriendlyName' => '2FA Code Length',
                'Type' => 'dropdown',
                'Options' => [
                    '4' => '4 Digits',
                    '6' => '6 Digits',
                    '8' => '8 Digits',
                ],
                'Default' => '6',
            ],
            'twofa_code_type' => [
                'FriendlyName' => '2FA Code Type',
                'Type' => 'dropdown',
                'Options' => [
                    'numeric' => 'Numeric Only (e.g. 123456)',
                    'alphanumeric' => 'Alphanumeric (e.g. A1B2C3)',
                    'alpha' => 'Alphabetical (e.g. ABCDEF)',
                ],
                'Default' => 'numeric',
            ],
            'twofa_code_expiry' => [
                'FriendlyName' => '2FA Code Expiry (Minutes)',
                'Type' => 'text',
                'Size' => '5',
                'Default' => '10',
            ],
            'twofa_max_attempts' => [
                'FriendlyName' => 'Max Failed Attempts',
                'Type' => 'text',
                'Size' => '5',
                'Default' => '5',
                'Description' => 'Lockout after this many failed 2FA tries',
            ],
            'twofa_remember_device' => [
                'FriendlyName' => 'Remember Trusted Devices',
                'Type' => 'yesno',
                'Default' => 'yes',
                'Description' => 'Option to trust the device for X days',
            ],
            'twofa_remember_days' => [
                'FriendlyName' => 'Device Trust Duration (Days)',
                'Type' => 'text',
                'Size' => '5',
                'Default' => '30',
            ],
        ],
    ];
}

/**
 * Module Activation
 *
 * @return array
 */
function email_verification_pro_activate()
{
    try {
        // Create verification tokens table
        if (!Capsule::schema()->hasTable('mod_email_verification_tokens')) {
            Capsule::schema()->create('mod_email_verification_tokens', function ($table) {
                $table->increments('id');
                $table->integer('client_id')->unsigned();
                $table->string('email', 255);
                $table->string('token', 64)->unique();
                $table->boolean('verified')->default(false);
                $table->timestamp('verified_at')->nullable();
                $table->string('verified_ip', 45)->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('expires_at');
                $table->integer('resend_count')->default(0);
                $table->timestamp('last_resend_at')->nullable();
                $table->index(['client_id']);
                $table->index(['token']);
                $table->index(['email']);
            });
        }

        // Create banned emails table
        if (!Capsule::schema()->hasTable('mod_email_verification_banned_emails')) {
            Capsule::schema()->create('mod_email_verification_banned_emails', function ($table) {
                $table->increments('id');
                $table->string('email', 255);
                $table->string('reason', 255)->nullable();
                $table->integer('added_by_admin')->unsigned()->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->unique(['email']);
            });
        }

        // Create banned IPs table
        if (!Capsule::schema()->hasTable('mod_email_verification_banned_ips')) {
            Capsule::schema()->create('mod_email_verification_banned_ips', function ($table) {
                $table->increments('id');
                $table->string('ip_address', 45);
                $table->string('reason', 255)->nullable();
                $table->integer('added_by_admin')->unsigned()->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->unique(['ip_address']);
            });
        }

        // Create banned email providers table
        if (!Capsule::schema()->hasTable('mod_email_verification_banned_providers')) {
            Capsule::schema()->create('mod_email_verification_banned_providers', function ($table) {
                $table->increments('id');
                $table->string('domain', 255);
                $table->string('reason', 255)->nullable();
                $table->integer('added_by_admin')->unsigned()->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->unique(['domain']);
            });
        }

        // Create activity log table
        if (!Capsule::schema()->hasTable('mod_email_verification_log')) {
            Capsule::schema()->create('mod_email_verification_log', function ($table) {
                $table->increments('id');
                $table->integer('client_id')->unsigned()->nullable();
                $table->string('email', 255);
                $table->string('ip_address', 45);
                $table->string('action', 50);
                $table->text('details')->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->index(['client_id']);
                $table->index(['action']);
                $table->index(['created_at']);
            });
        }

        // Create 2FA codes table
        if (!Capsule::schema()->hasTable('mod_evp_twofa_codes')) {
            Capsule::schema()->create('mod_evp_twofa_codes', function ($table) {
                $table->increments('id');
                $table->integer('client_id')->unsigned();
                $table->string('email', 255);
                $table->string('code', 255);
                $table->string('plain_code', 20)->nullable();
                $table->integer('attempts')->default(0);
                $table->string('ip_address', 45);
                $table->text('user_agent')->nullable();
                $table->timestamp('expires_at');
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->nullable();
                $table->index(['client_id']);
                $table->index(['expires_at']);
            });
        }

        // Create trusted devices table
        if (!Capsule::schema()->hasTable('mod_evp_remembered_devices')) {
            Capsule::schema()->create('mod_evp_remembered_devices', function ($table) {
                $table->increments('id');
                $table->integer('client_id')->unsigned();
                $table->string('device_token', 64);
                $table->string('ip_address', 45);
                $table->text('user_agent')->nullable();
                $table->timestamp('expires_at');
                $table->timestamp('created_at')->useCurrent();
                $table->index(['client_id', 'device_token']);
            });
        }

        // Create email templates table
        require_once __DIR__ . '/lib/EmailTemplateManager.php';
        \WHMCS\Module\Addon\EmailVerificationPro\EmailTemplateManager::initialize();

        // Insert default banned disposable email providers
        $disposableProviders = [
            'tempmail.com', 'guerrillamail.com', 'mailinator.com', '10minutemail.com',
            'throwaway.email', 'fakeinbox.com', 'trashmail.com', 'getnada.com',
            'temp-mail.org', 'disposablemail.com', 'yopmail.com', 'sharklasers.com',
        ];

        foreach ($disposableProviders as $provider) {
            Capsule::table('mod_email_verification_banned_providers')->insertOrIgnore([
                'domain' => $provider,
                'reason' => 'Disposable email provider',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }

        return [
            'status' => 'success',
            'description' => 'Email Verification Pro has been activated successfully.',
        ];

    } catch (\Exception $e) {
        return [
            'status' => 'error',
            'description' => 'Error activating module: ' . $e->getMessage(),
        ];
    }
}

/**
 * Module Deactivation
 *
 * @return array
 */
function email_verification_pro_deactivate()
{
    try {
        // Optionally drop tables - commented out to preserve data
        // Capsule::schema()->dropIfExists('mod_email_verification_tokens');
        // Capsule::schema()->dropIfExists('mod_email_verification_banned_emails');
        // Capsule::schema()->dropIfExists('mod_email_verification_banned_ips');
        // Capsule::schema()->dropIfExists('mod_email_verification_banned_providers');
        // Capsule::schema()->dropIfExists('mod_email_verification_log');

        return [
            'status' => 'success',
            'description' => 'Email Verification Pro has been deactivated. Database tables preserved.',
        ];

    } catch (\Exception $e) {
        return [
            'status' => 'error',
            'description' => 'Error deactivating module: ' . $e->getMessage(),
        ];
    }
}

/**
 * Module Upgrade
 *
 * @param array $vars
 * @return void
 */
function email_verification_pro_upgrade($vars)
{
    $currentVersion = $vars['version'];

    // Handle version upgrades here
    // if (version_compare($currentVersion, '1.1.0', '<')) {
    //     // Upgrade to 1.1.0
    // }
}

/**
 * Admin Area Output
 *
 * @param array $vars
 * @return string
 */
function email_verification_pro_output($vars)
{
    $modulelink = $vars['modulelink'];
    $version = $vars['version'];
    $LANG = $vars['_lang'];

    // Get current action
    $action = isset($_GET['action']) ? $_GET['action'] : 'dashboard';

    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        email_verification_pro_handle_post($vars);
    }

    // Output CSS
    echo '<style>
        .evp-card { background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 20px; margin-bottom: 20px; }
        .evp-card h3 { margin-top: 0; color: #333; border-bottom: 2px solid #4a90d9; padding-bottom: 10px; }
        .evp-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 20px; }
        .evp-stat { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 8px; padding: 20px; text-align: center; }
        .evp-stat.success { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        .evp-stat.warning { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .evp-stat.info { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        .evp-stat h4 { margin: 0 0 10px 0; font-size: 14px; opacity: 0.9; }
        .evp-stat .number { font-size: 36px; font-weight: bold; }
        .evp-tabs { display: flex; gap: 10px; margin-bottom: 20px; }
        .evp-tab { padding: 10px 20px; background: #f5f5f5; border: none; cursor: pointer; border-radius: 5px; text-decoration: none; color: #333; }
        .evp-tab.active, .evp-tab:hover { background: #4a90d9; color: white; }
        .evp-table { width: 100%; border-collapse: collapse; }
        .evp-table th, .evp-table td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        .evp-table th { background: #f8f9fa; font-weight: 600; }
        .evp-table tr:hover { background: #f8f9fa; }
        .evp-badge { padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; }
        .evp-badge.verified { background: #d4edda; color: #155724; }
        .evp-badge.unverified { background: #f8d7da; color: #721c24; }
        .evp-badge.banned { background: #fff3cd; color: #856404; }
        .evp-btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
        .evp-btn-primary { background: #4a90d9; color: white; }
        .evp-btn-danger { background: #dc3545; color: white; }
        .evp-btn-success { background: #28a745; color: white; }
        .evp-btn:hover { opacity: 0.9; }
        .evp-form-group { margin-bottom: 15px; }
        .evp-form-group label { display: block; margin-bottom: 5px; font-weight: 500; }
        .evp-form-group input, .evp-form-group select, .evp-form-group textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
        .evp-alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .evp-alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .evp-alert-danger { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>';

    // Show success/error messages
    if (isset($_SESSION['evp_message'])) {
        $msgType = $_SESSION['evp_message_type'] ?? 'success';
        echo '<div class="evp-alert evp-alert-' . $msgType . '">' . $_SESSION['evp_message'] . '</div>';
        unset($_SESSION['evp_message'], $_SESSION['evp_message_type']);
    }

    // Navigation tabs
    echo '<div class="evp-tabs">
        <a href="' . $modulelink . '&action=dashboard" class="evp-tab ' . ($action === 'dashboard' ? 'active' : '') . '">Dashboard</a>
        <a href="' . $modulelink . '&action=pending" class="evp-tab ' . ($action === 'pending' ? 'active' : '') . '">Pending Verifications</a>
        <a href="' . $modulelink . '&action=verified" class="evp-tab ' . ($action === 'verified' ? 'active' : '') . '">Verified Clients</a>
        <a href="' . $modulelink . '&action=banned_emails" class="evp-tab ' . ($action === 'banned_emails' ? 'active' : '') . '">Banned Emails</a>
        <a href="' . $modulelink . '&action=banned_ips" class="evp-tab ' . ($action === 'banned_ips' ? 'active' : '') . '">Banned IPs</a>
        <a href="' . $modulelink . '&action=banned_providers" class="evp-tab ' . ($action === 'banned_providers' ? 'active' : '') . '">Banned Providers</a>
        <a href="' . $modulelink . '&action=templates" class="evp-tab ' . ($action === 'templates' ? 'active' : '') . '">Email Templates</a>
        <a href="' . $modulelink . '&action=logs" class="evp-tab ' . ($action === 'logs' ? 'active' : '') . '">Activity Logs</a>
    </div>';

    // Render appropriate page
    switch ($action) {
        case 'pending':
            email_verification_pro_render_pending($modulelink);
            break;
        case 'verified':
            email_verification_pro_render_verified($modulelink);
            break;
        case 'banned_emails':
            email_verification_pro_render_banned_emails($modulelink);
            break;
        case 'banned_ips':
            email_verification_pro_render_banned_ips($modulelink);
            break;
        case 'banned_providers':
            email_verification_pro_render_banned_providers($modulelink);
            break;
        case 'templates':
            require_once __DIR__ . '/lib/EmailTemplateManager.php';
            email_verification_pro_render_templates($modulelink);
            break;
        case 'edit_template':
            require_once __DIR__ . '/lib/EmailTemplateManager.php';
            email_verification_pro_render_edit_template($modulelink);
            break;
        case 'logs':
            email_verification_pro_render_logs($modulelink);
            break;
        case 'dashboard':
        default:
            email_verification_pro_render_dashboard($modulelink);
            break;
    }
}

/**
 * Render Email Templates
 */
function email_verification_pro_render_templates($modulelink)
{
    $templates = \WHMCS\Module\Addon\EmailVerificationPro\EmailTemplateManager::getAllTemplates();

    echo '<div class="evp-card">
        <h3>Email Templates</h3>
        <p>Customize the emails sent by the module to your customers.</p>
        <table class="evp-table">
            <thead>
                <tr>
                    <th>Template Name</th>
                    <th>Subject</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>';

    foreach ($templates as $tpl) {
        echo '<tr>
            <td><strong>' . htmlspecialchars($tpl->name) . '</strong></td>
            <td>' . htmlspecialchars($tpl->subject) . '</td>
            <td>' . ($tpl->is_active ? '<span class="evp-badge verified">Active</span>' : '<span class="evp-badge banned">Inactive</span>') . '</td>
            <td>
                <a href="' . $modulelink . '&action=edit_template&key=' . $tpl->template_key . '" class="evp-btn evp-btn-primary">Edit Template</a>
                <form method="post" style="display: inline;">
                    <input type="hidden" name="action" value="reset_template">
                    <input type="hidden" name="key" value="' . $tpl->template_key . '">
                    <button type="submit" class="evp-btn" onclick="return confirm(\'Reset to default?\')">Reset</button>
                </form>
            </td>
        </tr>';
    }

    echo '</tbody></table></div>';
}

/**
 * Render Edit Template
 */
function email_verification_pro_render_edit_template($modulelink)
{
    $key = $_GET['key'] ?? '';
    $template = \WHMCS\Module\Addon\EmailVerificationPro\EmailTemplateManager::getTemplate($key);

    if (!$template['name']) {
        echo 'Template not found.';
        return;
    }

    echo '<div class="evp-card">
        <h3>Edit Template: ' . htmlspecialchars($template['name']) . '</h3>
        <form method="post">
            <input type="hidden" name="action" value="update_template">
            <input type="hidden" name="key" value="' . htmlspecialchars($key) . '">
            
            <div class="evp-form-group">
                <label>Subject</label>
                <input type="text" name="subject" value="' . htmlspecialchars($template['subject']) . '" required>
            </div>
            
            <div class="evp-form-group">
                <label>Email Body (HTML Supported)</label>
                <textarea name="body" rows="20" required>' . htmlspecialchars($template['body']) . '</textarea>
            </div>
            
            <div class="evp-form-group">
                <label>Available Variables</label>
                <div style="background: #f8f9fa; padding: 10px; border-radius: 5px; font-family: monospace;">
                    ' . htmlspecialchars($template['variables']) . '
                </div>
            </div>
            
            <div class="evp-form-group">
                <label><input type="checkbox" name="is_active" ' . ($template['is_active'] ? 'checked' : '') . '> Template is Active</label>
            </div>
            
            <div style="margin-top: 20px;">
                <button type="submit" class="evp-btn evp-btn-success">Save Changes</button>
                <a href="' . $modulelink . '&action=templates" class="evp-btn">Back to Templates</a>
            </div>
        </form>
    </div>';
}

/**
 * Render Dashboard
 */
function email_verification_pro_render_dashboard($modulelink)
{
    // Get statistics
    $totalPending = Capsule::table('mod_email_verification_tokens')
        ->where('verified', false)
        ->whereRaw('expires_at > NOW()')
        ->count();

    $totalVerified = Capsule::table('mod_email_verification_tokens')
        ->where('verified', true)
        ->count();

    $verifiedToday = Capsule::table('mod_email_verification_tokens')
        ->where('verified', true)
        ->whereDate('verified_at', date('Y-m-d'))
        ->count();

    $bannedEmails = Capsule::table('mod_email_verification_banned_emails')->count();
    $bannedIPs = Capsule::table('mod_email_verification_banned_ips')->count();
    $bannedProviders = Capsule::table('mod_email_verification_banned_providers')->count();

    echo '<div class="evp-stats">
        <div class="evp-stat warning">
            <h4>Pending Verifications</h4>
            <div class="number">' . $totalPending . '</div>
        </div>
        <div class="evp-stat success">
            <h4>Total Verified</h4>
            <div class="number">' . $totalVerified . '</div>
        </div>
        <div class="evp-stat info">
            <h4>Verified Today</h4>
            <div class="number">' . $verifiedToday . '</div>
        </div>
        <div class="evp-stat">
            <h4>Blocked (Email/IP/Provider)</h4>
            <div class="number">' . ($bannedEmails + $bannedIPs) . ' / ' . $bannedProviders . '</div>
        </div>
    </div>';

    // Recent activity
    echo '<div class="evp-card">
        <h3>Recent Activity</h3>';

    $recentLogs = Capsule::table('mod_email_verification_log')
        ->orderBy('created_at', 'desc')
        ->limit(10)
        ->get();

    if ($recentLogs->isEmpty()) {
        echo '<p>No activity logged yet.</p>';
    } else {
        echo '<table class="evp-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Email</th>
                    <th>Action</th>
                    <th>IP Address</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($recentLogs as $log) {
            echo '<tr>
                <td>' . date('M j, Y H:i', strtotime($log->created_at)) . '</td>
                <td>' . htmlspecialchars($log->email) . '</td>
                <td><span class="evp-badge">' . htmlspecialchars($log->action) . '</span></td>
                <td>' . htmlspecialchars($log->ip_address) . '</td>
                <td>' . htmlspecialchars($log->details ?? '-') . '</td>
            </tr>';
        }

        echo '</tbody></table>';
    }

    echo '</div>';

    // Quick actions
    echo '<div class="evp-card">
        <h3>Quick Actions</h3>
        <p>
            <a href="' . $modulelink . '&action=pending" class="evp-btn evp-btn-primary">View Pending Verifications</a>
            <a href="' . $modulelink . '&action=banned_emails" class="evp-btn evp-btn-danger">Manage Banned Emails</a>
            <a href="' . $modulelink . '&action=logs" class="evp-btn">View All Logs</a>
        </p>
    </div>';
}

/**
 * Render Pending Verifications
 */
function email_verification_pro_render_pending($modulelink)
{
    $pending = Capsule::table('mod_email_verification_tokens')
        ->leftJoin('tblclients', 'mod_email_verification_tokens.client_id', '=', 'tblclients.id')
        ->where('mod_email_verification_tokens.verified', false)
        ->select(
            'mod_email_verification_tokens.*',
            'tblclients.firstname',
            'tblclients.lastname',
            'tblclients.status as client_status'
        )
        ->orderBy('mod_email_verification_tokens.created_at', 'desc')
        ->get();

    echo '<div class="evp-card">
        <h3>Pending Email Verifications (' . $pending->count() . ')</h3>';

    if ($pending->isEmpty()) {
        echo '<p>No pending verifications.</p>';
    } else {
        echo '<table class="evp-table">
            <thead>
                <tr>
                    <th>Client</th>
                    <th>Email</th>
                    <th>Created</th>
                    <th>Expires</th>
                    <th>Resends</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($pending as $row) {
            $expired = strtotime($row->expires_at) < time();
            echo '<tr>
                <td><a href="clientssummary.php?userid=' . $row->client_id . '">' . htmlspecialchars($row->firstname . ' ' . $row->lastname) . '</a></td>
                <td>' . htmlspecialchars($row->email) . '</td>
                <td>' . date('M j, Y H:i', strtotime($row->created_at)) . '</td>
                <td>' . date('M j, Y H:i', strtotime($row->expires_at)) . '</td>
                <td>' . $row->resend_count . '</td>
                <td><span class="evp-badge ' . ($expired ? 'banned' : 'unverified') . '">' . ($expired ? 'Expired' : 'Pending') . '</span></td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="action" value="verify_manual">
                        <input type="hidden" name="client_id" value="' . $row->client_id . '">
                        <button type="submit" class="evp-btn evp-btn-success" onclick="return confirm(\'Manually verify this email?\')">Verify</button>
                    </form>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="action" value="resend">
                        <input type="hidden" name="client_id" value="' . $row->client_id . '">
                        <button type="submit" class="evp-btn evp-btn-primary">Resend</button>
                    </form>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="action" value="ban_email">
                        <input type="hidden" name="email" value="' . $row->email . '">
                        <button type="submit" class="evp-btn evp-btn-danger" onclick="return confirm(\'Ban this email address?\')">Ban</button>
                    </form>
                </td>
            </tr>';
        }

        echo '</tbody></table>';
    }

    echo '</div>';
}

/**
 * Render Verified Clients
 */
function email_verification_pro_render_verified($modulelink)
{
    $verified = Capsule::table('mod_email_verification_tokens')
        ->leftJoin('tblclients', 'mod_email_verification_tokens.client_id', '=', 'tblclients.id')
        ->where('mod_email_verification_tokens.verified', true)
        ->select(
            'mod_email_verification_tokens.*',
            'tblclients.firstname',
            'tblclients.lastname'
        )
        ->orderBy('mod_email_verification_tokens.verified_at', 'desc')
        ->limit(100)
        ->get();

    echo '<div class="evp-card">
        <h3>Recently Verified Clients</h3>';

    if ($verified->isEmpty()) {
        echo '<p>No verified clients yet.</p>';
    } else {
        echo '<table class="evp-table">
            <thead>
                <tr>
                    <th>Client</th>
                    <th>Email</th>
                    <th>Verified At</th>
                    <th>Verified IP</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($verified as $row) {
            echo '<tr>
                <td><a href="clientssummary.php?userid=' . $row->client_id . '">' . htmlspecialchars($row->firstname . ' ' . $row->lastname) . '</a></td>
                <td>' . htmlspecialchars($row->email) . '</td>
                <td>' . date('M j, Y H:i', strtotime($row->verified_at)) . '</td>
                <td>' . htmlspecialchars($row->verified_ip ?? '-') . '</td>
            </tr>';
        }

        echo '</tbody></table>';
    }

    echo '</div>';
}

/**
 * Render Banned Emails
 */
function email_verification_pro_render_banned_emails($modulelink)
{
    $banned = Capsule::table('mod_email_verification_banned_emails')
        ->orderBy('created_at', 'desc')
        ->get();

    echo '<div class="evp-card">
        <h3>Banned Email Addresses</h3>
        
        <form method="post" style="margin-bottom: 20px;">
            <input type="hidden" name="action" value="add_banned_email">
            <div style="display: flex; gap: 10px;">
                <input type="email" name="email" placeholder="Email address to ban" required style="flex: 1;">
                <input type="text" name="reason" placeholder="Reason (optional)" style="flex: 1;">
                <button type="submit" class="evp-btn evp-btn-danger">Add Ban</button>
            </div>
        </form>';

    if ($banned->isEmpty()) {
        echo '<p>No banned emails.</p>';
    } else {
        echo '<table class="evp-table">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Reason</th>
                    <th>Added</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($banned as $row) {
            echo '<tr>
                <td>' . htmlspecialchars($row->email) . '</td>
                <td>' . htmlspecialchars($row->reason ?? '-') . '</td>
                <td>' . date('M j, Y', strtotime($row->created_at)) . '</td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="action" value="remove_banned_email">
                        <input type="hidden" name="id" value="' . $row->id . '">
                        <button type="submit" class="evp-btn evp-btn-danger" onclick="return confirm(\'Remove this ban?\')">Remove</button>
                    </form>
                </td>
            </tr>';
        }

        echo '</tbody></table>';
    }

    echo '</div>';
}

/**
 * Render Banned IPs
 */
function email_verification_pro_render_banned_ips($modulelink)
{
    $banned = Capsule::table('mod_email_verification_banned_ips')
        ->orderBy('created_at', 'desc')
        ->get();

    echo '<div class="evp-card">
        <h3>Banned IP Addresses</h3>
        
        <form method="post" style="margin-bottom: 20px;">
            <input type="hidden" name="action" value="add_banned_ip">
            <div style="display: flex; gap: 10px;">
                <input type="text" name="ip_address" placeholder="IP address to ban" required style="flex: 1;">
                <input type="text" name="reason" placeholder="Reason (optional)" style="flex: 1;">
                <button type="submit" class="evp-btn evp-btn-danger">Add Ban</button>
            </div>
        </form>';

    if ($banned->isEmpty()) {
        echo '<p>No banned IPs.</p>';
    } else {
        echo '<table class="evp-table">
            <thead>
                <tr>
                    <th>IP Address</th>
                    <th>Reason</th>
                    <th>Added</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($banned as $row) {
            echo '<tr>
                <td>' . htmlspecialchars($row->ip_address) . '</td>
                <td>' . htmlspecialchars($row->reason ?? '-') . '</td>
                <td>' . date('M j, Y', strtotime($row->created_at)) . '</td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="action" value="remove_banned_ip">
                        <input type="hidden" name="id" value="' . $row->id . '">
                        <button type="submit" class="evp-btn evp-btn-danger" onclick="return confirm(\'Remove this ban?\')">Remove</button>
                    </form>
                </td>
            </tr>';
        }

        echo '</tbody></table>';
    }

    echo '</div>';
}

/**
 * Render Banned Providers
 */
function email_verification_pro_render_banned_providers($modulelink)
{
    $banned = Capsule::table('mod_email_verification_banned_providers')
        ->orderBy('domain', 'asc')
        ->get();

    echo '<div class="evp-card">
        <h3>Banned Email Providers (Disposable Email Domains)</h3>
        
        <form method="post" style="margin-bottom: 20px;">
            <input type="hidden" name="action" value="add_banned_provider">
            <div style="display: flex; gap: 10px;">
                <input type="text" name="domain" placeholder="Domain (e.g., tempmail.com)" required style="flex: 1;">
                <input type="text" name="reason" placeholder="Reason (optional)" style="flex: 1;">
                <button type="submit" class="evp-btn evp-btn-danger">Add Provider</button>
            </div>
        </form>';

    if ($banned->isEmpty()) {
        echo '<p>No banned providers.</p>';
    } else {
        echo '<table class="evp-table">
            <thead>
                <tr>
                    <th>Domain</th>
                    <th>Reason</th>
                    <th>Added</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($banned as $row) {
            echo '<tr>
                <td>' . htmlspecialchars($row->domain) . '</td>
                <td>' . htmlspecialchars($row->reason ?? '-') . '</td>
                <td>' . date('M j, Y', strtotime($row->created_at)) . '</td>
                <td>
                    <form method="post" style="display: inline;">
                        <input type="hidden" name="action" value="remove_banned_provider">
                        <input type="hidden" name="id" value="' . $row->id . '">
                        <button type="submit" class="evp-btn evp-btn-danger" onclick="return confirm(\'Remove this provider?\')">Remove</button>
                    </form>
                </td>
            </tr>';
        }

        echo '</tbody></table>';
    }

    echo '</div>';
}

/**
 * Render Activity Logs
 */
function email_verification_pro_render_logs($modulelink)
{
    $logs = Capsule::table('mod_email_verification_log')
        ->orderBy('created_at', 'desc')
        ->limit(200)
        ->get();

    echo '<div class="evp-card">
        <h3>Activity Logs</h3>
        
        <form method="post" style="margin-bottom: 20px;">
            <input type="hidden" name="action" value="clear_logs">
            <button type="submit" class="evp-btn evp-btn-danger" onclick="return confirm(\'Clear all logs? This cannot be undone.\')">Clear All Logs</button>
        </form>';

    if ($logs->isEmpty()) {
        echo '<p>No activity logs.</p>';
    } else {
        echo '<table class="evp-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Client ID</th>
                    <th>Email</th>
                    <th>Action</th>
                    <th>IP Address</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>';

        foreach ($logs as $log) {
            echo '<tr>
                <td>' . date('M j, Y H:i:s', strtotime($log->created_at)) . '</td>
                <td>' . ($log->client_id ? '<a href="clientssummary.php?userid=' . $log->client_id . '">#' . $log->client_id . '</a>' : '-') . '</td>
                <td>' . htmlspecialchars($log->email) . '</td>
                <td><span class="evp-badge">' . htmlspecialchars($log->action) . '</span></td>
                <td>' . htmlspecialchars($log->ip_address) . '</td>
                <td>' . htmlspecialchars($log->details ?? '-') . '</td>
            </tr>';
        }

        echo '</tbody></table>';
    }

    echo '</div>';
}

/**
 * Handle POST actions
 */
function email_verification_pro_handle_post($vars)
{
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'verify_manual':
            $clientId = (int) $_POST['client_id'];
            email_verification_pro_verify_client($clientId, true);
            $_SESSION['evp_message'] = 'Client verified successfully.';
            break;

        case 'resend':
            $clientId = (int) $_POST['client_id'];
            email_verification_pro_resend_verification($clientId);
            $_SESSION['evp_message'] = 'Verification email resent.';
            break;

        case 'ban_email':
            $email = trim($_POST['email']);
            Capsule::table('mod_email_verification_banned_emails')->insertOrIgnore([
                'email' => strtolower($email),
                'reason' => 'Banned from pending list',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $_SESSION['evp_message'] = 'Email banned successfully.';
            break;

        case 'add_banned_email':
            $email = strtolower(trim($_POST['email']));
            $reason = trim($_POST['reason'] ?? '');
            Capsule::table('mod_email_verification_banned_emails')->insertOrIgnore([
                'email' => $email,
                'reason' => $reason ?: null,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $_SESSION['evp_message'] = 'Email added to ban list.';
            break;

        case 'remove_banned_email':
            $id = (int) $_POST['id'];
            Capsule::table('mod_email_verification_banned_emails')->where('id', $id)->delete();
            $_SESSION['evp_message'] = 'Email removed from ban list.';
            break;

        case 'add_banned_ip':
            $ip = trim($_POST['ip_address']);
            $reason = trim($_POST['reason'] ?? '');
            Capsule::table('mod_email_verification_banned_ips')->insertOrIgnore([
                'ip_address' => $ip,
                'reason' => $reason ?: null,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $_SESSION['evp_message'] = 'IP added to ban list.';
            break;

        case 'remove_banned_ip':
            $id = (int) $_POST['id'];
            Capsule::table('mod_email_verification_banned_ips')->where('id', $id)->delete();
            $_SESSION['evp_message'] = 'IP removed from ban list.';
            break;

        case 'add_banned_provider':
            $domain = strtolower(trim($_POST['domain']));
            $reason = trim($_POST['reason'] ?? '');
            Capsule::table('mod_email_verification_banned_providers')->insertOrIgnore([
                'domain' => $domain,
                'reason' => $reason ?: null,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $_SESSION['evp_message'] = 'Provider added to ban list.';
            break;

        case 'remove_banned_provider':
            $id = (int) $_POST['id'];
            Capsule::table('mod_email_verification_banned_providers')->where('id', $id)->delete();
            $_SESSION['evp_message'] = 'Provider removed from ban list.';
            break;

        case 'clear_logs':
            Capsule::table('mod_email_verification_log')->truncate();
            $_SESSION['evp_message'] = 'All logs cleared.';
            break;

        case 'update_template':
            require_once __DIR__ . '/lib/EmailTemplateManager.php';
            $key = $_POST['key'];
            $data = [
                'subject' => $_POST['subject'],
                'body' => $_POST['body'],
                'is_active' => isset($_POST['is_active']),
            ];
            \WHMCS\Module\Addon\EmailVerificationPro\EmailTemplateManager::updateTemplate($key, $data);
            $_SESSION['evp_message'] = 'Template updated successfully.';
            break;

        case 'reset_template':
            require_once __DIR__ . '/lib/EmailTemplateManager.php';
            \WHMCS\Module\Addon\EmailVerificationPro\EmailTemplateManager::resetTemplate($_POST['key']);
            $_SESSION['evp_message'] = 'Template reset to default.';
            break;
    }

    $_SESSION['evp_message_type'] = 'success';
}

/**
 * Verify a client
 *
 * @param int $clientId
 * @param bool $manual
 */
function email_verification_pro_verify_client($clientId, $manual = false)
{
    Capsule::table('mod_email_verification_tokens')
        ->where('client_id', $clientId)
        ->update([
            'verified' => true,
            'verified_at' => date('Y-m-d H:i:s'),
            'verified_ip' => $manual ? 'ADMIN' : ($_SERVER['REMOTE_ADDR'] ?? ''),
        ]);

    // Log action
    $client = Capsule::table('tblclients')->where('id', $clientId)->first();
    email_verification_pro_log(
        $clientId,
        $client->email ?? '',
        $manual ? 'admin_verified' : 'verified',
        $manual ? 'ADMIN' : ($_SERVER['REMOTE_ADDR'] ?? ''),
        $manual ? 'Manually verified by admin' : 'Verified via link'
    );
}

/**
 * Resend verification email
 *
 * @param int $clientId
 */
function email_verification_pro_resend_verification($clientId)
{
    require_once __DIR__ . '/lib/EmailVerificationHelper.php';
    \WHMCS\Module\Addon\EmailVerificationPro\EmailVerificationHelper::resendVerificationEmail($clientId);
}

/**
 * Log activity
 */
function email_verification_pro_log($clientId, $email, $action, $ip, $details = null)
{
    Capsule::table('mod_email_verification_log')->insert([
        'client_id' => $clientId,
        'email' => $email,
        'action' => $action,
        'ip_address' => $ip,
        'details' => $details,
        'created_at' => date('Y-m-d H:i:s'),
    ]);
}

/**
 * Client Area Output
 *
 * @param array $vars
 * @return array
 */
function email_verification_pro_clientarea($vars)
{
    // This addon doesn't have a client area page itself
    // The verification is handled via hooks
    return [
        'pagetitle' => 'Email Verification',
        'templatefile' => 'clientarea',
        'vars' => [],
    ];
}
