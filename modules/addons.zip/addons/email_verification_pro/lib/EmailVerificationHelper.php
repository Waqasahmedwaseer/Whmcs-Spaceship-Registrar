<?php
/**
 * Email Verification Pro - Helper Class
 *
 * Contains helper functions for email verification operations.
 *
 * @copyright 2026
 * @license Proprietary
 */

namespace WHMCS\Module\Addon\EmailVerificationPro;

use WHMCS\Database\Capsule;

class EmailVerificationHelper
{
    /**
     * Module configuration cache
     */
    private static $configCache = null;

    /**
     * Check if module is active
     *
     * @return bool
     */
    public static function isModuleActive()
    {
        $addon = Capsule::table('tbladdonmodules')
            ->where('module', 'email_verification_pro')
            ->where('setting', 'version')
            ->first();

        return $addon !== null;
    }

    /**
     * Get module configuration
     *
     * @return array
     */
    public static function getModuleConfig()
    {
        if (self::$configCache !== null) {
            return self::$configCache;
        }

        $settings = Capsule::table('tbladdonmodules')
            ->where('module', 'email_verification_pro')
            ->pluck('value', 'setting')
            ->toArray();

        self::$configCache = [
            'verification_type' => $settings['verification_type'] ?? 'all_pages',
            'auto_terminate_enabled' => ($settings['auto_terminate_enabled'] ?? '') === 'on',
            'auto_terminate_days' => (int) ($settings['auto_terminate_days'] ?? 7),
            'auto_delete_enabled' => ($settings['auto_delete_enabled'] ?? '') === 'on',
            'auto_delete_days' => (int) ($settings['auto_delete_days'] ?? 30),
            'resend_reminder_days' => (int) ($settings['resend_reminder_days'] ?? 3),
            'token_expiry_hours' => (int) ($settings['token_expiry_hours'] ?? 48),
            'lock_email_change' => ($settings['lock_email_change'] ?? '') === 'on',
            'allow_support_tickets' => ($settings['allow_support_tickets'] ?? '') === 'on',
            'allow_profile_edit' => ($settings['allow_profile_edit'] ?? '') === 'on',
            'captcha_type' => $settings['captcha_type'] ?? 'none',
            'recaptcha_site_key' => $settings['recaptcha_site_key'] ?? '',
            'recaptcha_secret_key' => $settings['recaptcha_secret_key'] ?? '',
            'turnstile_site_key' => $settings['turnstile_site_key'] ?? '',
            'turnstile_secret_key' => $settings['turnstile_secret_key'] ?? '',
            'send_welcome_after_verify' => ($settings['send_welcome_after_verify'] ?? '') === 'on',
            'redirect_after_verify' => $settings['redirect_after_verify'] ?? 'clientarea',
        ];

        return self::$configCache;
    }

    /**
     * Check if a client is verified
     *
     * @param int $clientId
     * @return bool
     */
    public static function isClientVerified($clientId)
    {
        $token = Capsule::table('mod_email_verification_tokens')
            ->where('client_id', $clientId)
            ->where('verified', true)
            ->first();

        return $token !== null;
    }

    /**
     * Check if an email is banned
     *
     * @param string $email
     * @return bool
     */
    public static function isEmailBanned($email)
    {
        $email = strtolower(trim($email));

        // Check exact email
        $banned = Capsule::table('mod_email_verification_banned_emails')
            ->where('email', $email)
            ->exists();

        if ($banned) {
            return true;
        }

        // Check email provider/domain
        $domain = substr(strrchr($email, "@"), 1);
        if ($domain) {
            $providerBanned = Capsule::table('mod_email_verification_banned_providers')
                ->where('domain', $domain)
                ->exists();

            if ($providerBanned) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if an IP is banned
     *
     * @param string $ip
     * @return bool
     */
    public static function isIpBanned($ip)
    {
        return Capsule::table('mod_email_verification_banned_ips')
            ->where('ip_address', $ip)
            ->exists();
    }

    /**
     * Generate a secure verification token
     *
     * @return string
     */
    public static function generateToken()
    {
        return bin2hex(random_bytes(32));
    }

    /**
     * Create a verification token for a client
     *
     * @param int $clientId
     * @param string $email
     * @return string Token
     */
    public static function createVerificationToken($clientId, $email)
    {
        $config = self::getModuleConfig();
        $token = self::generateToken();
        $expiryHours = $config['token_expiry_hours'];

        // Delete any existing tokens for this client
        Capsule::table('mod_email_verification_tokens')
            ->where('client_id', $clientId)
            ->delete();

        // Create new token
        Capsule::table('mod_email_verification_tokens')->insert([
            'client_id' => $clientId,
            'email' => strtolower($email),
            'token' => $token,
            'verified' => false,
            'created_at' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', strtotime("+{$expiryHours} hours")),
            'resend_count' => 0,
        ]);

        return $token;
    }

    /**
     * Send verification email to a client
     *
     * @param int $clientId
     * @return bool
     */
    public static function sendVerificationEmail($clientId)
    {
        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        if (!$client) {
            return false;
        }

        $token = Capsule::table('mod_email_verification_tokens')
            ->where('client_id', $clientId)
            ->where('verified', false)
            ->first();

        if (!$token) {
            // Create a new token
            $tokenString = self::createVerificationToken($clientId, $client->email);
        } else {
            $tokenString = $token->token;
        }

        // Get system URL
        $systemUrl = \WHMCS\Config\Setting::getValue('SystemURL');
        $verifyUrl = rtrim($systemUrl, '/') . '/index.php?m=email_verification_pro&action=verify&token=' . $tokenString;

        // Send email using WHMCS email template or custom email
        $command = 'SendEmail';
        $postData = [
            'messagename' => 'Email Verification Required',
            'id' => $clientId,
            'customtype' => 'general',
            'customsubject' => 'Please Verify Your Email Address',
            'custommessage' => self::getVerificationEmailContent($client, $verifyUrl),
        ];

        // Try to use localAPI if available
        if (function_exists('localAPI')) {
            $results = localAPI($command, $postData);
            return $results['result'] === 'success';
        }

        return false;
    }

    /**
     * Resend verification email
     *
     * @param int $clientId
     * @return bool
     */
    public static function resendVerificationEmail($clientId)
    {
        $config = self::getModuleConfig();

        // Regenerate token
        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        if (!$client) {
            return false;
        }

        // Update existing token or create new one
        $existingToken = Capsule::table('mod_email_verification_tokens')
            ->where('client_id', $clientId)
            ->first();

        if ($existingToken && !$existingToken->verified) {
            // Update existing token
            $newToken = self::generateToken();
            $expiryHours = $config['token_expiry_hours'];

            Capsule::table('mod_email_verification_tokens')
                ->where('client_id', $clientId)
                ->update([
                    'token' => $newToken,
                    'expires_at' => date('Y-m-d H:i:s', strtotime("+{$expiryHours} hours")),
                    'resend_count' => $existingToken->resend_count + 1,
                    'last_resend_at' => date('Y-m-d H:i:s'),
                ]);
        } else {
            self::createVerificationToken($clientId, $client->email);
        }

        // Send email
        $result = self::sendVerificationEmail($clientId);

        // Log action
        self::logAction($clientId, $client->email, 'resend', $_SERVER['REMOTE_ADDR'] ?? 'SYSTEM', 'Verification email resent');

        return $result;
    }

    /**
     * Verify a token
     *
     * @param string $token
     * @return array|false Client data if valid, false otherwise
     */
    public static function verifyToken($token)
    {
        $tokenData = Capsule::table('mod_email_verification_tokens')
            ->where('token', $token)
            ->where('verified', false)
            ->first();

        if (!$tokenData) {
            return ['error' => 'Invalid or already used verification token.'];
        }

        // Check if expired
        if (strtotime($tokenData->expires_at) < time()) {
            return ['error' => 'This verification link has expired. Please request a new one.'];
        }

        // Mark as verified
        Capsule::table('mod_email_verification_tokens')
            ->where('id', $tokenData->id)
            ->update([
                'verified' => true,
                'verified_at' => date('Y-m-d H:i:s'),
                'verified_ip' => $_SERVER['REMOTE_ADDR'] ?? '',
            ]);

        // Get client
        $client = Capsule::table('tblclients')->where('id', $tokenData->client_id)->first();

        // Log action
        self::logAction(
            $tokenData->client_id,
            $tokenData->email,
            'verified',
            $_SERVER['REMOTE_ADDR'] ?? '',
            'Email verified successfully'
        );

        // Send welcome email if configured
        $config = self::getModuleConfig();
        if ($config['send_welcome_after_verify'] && $client) {
            if (function_exists('localAPI')) {
                localAPI('SendEmail', [
                    'messagename' => 'Client Signup Email',
                    'id' => $tokenData->client_id,
                ]);
            }
        }

        return [
            'success' => true,
            'client_id' => $tokenData->client_id,
            'email' => $tokenData->email,
        ];
    }

    /**
     * Check if verification is required and handle redirect
     *
     * @param array $vars
     * @param string $page
     * @return array
     */
    public static function checkVerificationRequired($vars, $page)
    {
        if (!self::isModuleActive()) {
            return [];
        }

        $config = self::getModuleConfig();
        $clientId = isset($_SESSION['uid']) ? (int) $_SESSION['uid'] : 0;

        if ($clientId <= 0) {
            return [];
        }

        if (self::isClientVerified($clientId)) {
            return [];
        }

        // Client not verified, show verification notice
        return [
            'verificationRequired' => true,
            'verificationMessage' => 'Please verify your email address to continue.',
            'verificationLink' => 'index.php?m=email_verification_pro&action=verify',
        ];
    }

    /**
     * Log an action
     *
     * @param int $clientId
     * @param string $email
     * @param string $action
     * @param string $ip
     * @param string|null $details
     */
    public static function logAction($clientId, $email, $action, $ip, $details = null)
    {
        Capsule::table('mod_email_verification_log')->insert([
            'client_id' => $clientId,
            'email' => $email,
            'action' => $action,
            'ip_address' => $ip,
            'details' => $details,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Get verification email content
     *
     * @param object $client
     * @param string $verifyUrl
     * @return string
     */
    private static function getVerificationEmailContent($client, $verifyUrl)
    {
        $config = self::getModuleConfig();
        $expiryHours = $config['token_expiry_hours'];

        $html = '
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center;">
                <h1 style="margin: 0;">Email Verification Required</h1>
            </div>
            <div style="padding: 30px; background: #f9f9f9;">
                <p>Hello ' . htmlspecialchars($client->firstname) . ',</p>
                <p>Thank you for registering with us. To complete your registration and access your account, please verify your email address by clicking the button below:</p>
                <div style="text-align: center; margin: 30px 0;">
                    <a href="' . $verifyUrl . '" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Verify My Email</a>
                </div>
                <p>Or copy and paste this link into your browser:</p>
                <p style="background: #eee; padding: 10px; word-break: break-all; font-size: 12px;">' . $verifyUrl . '</p>
                <p><strong>This link will expire in ' . $expiryHours . ' hours.</strong></p>
                <p>If you did not create an account, please ignore this email.</p>
            </div>
            <div style="padding: 20px; text-align: center; color: #666; font-size: 12px;">
                <p>This is an automated message. Please do not reply directly to this email.</p>
            </div>
        </div>';

        return $html;
    }

    /**
     * Verify reCAPTCHA v3
     *
     * @param string $token
     * @return bool
     */
    public static function verifyRecaptcha($token)
    {
        $config = self::getModuleConfig();
        
        if (empty($config['recaptcha_secret_key'])) {
            return true; // Skip if not configured
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'secret' => $config['recaptcha_secret_key'],
            'response' => $token,
            'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);

        return isset($result['success']) && $result['success'] === true && ($result['score'] ?? 0) >= 0.5;
    }

    /**
     * Verify Cloudflare Turnstile
     *
     * @param string $token
     * @return bool
     */
    public static function verifyTurnstile($token)
    {
        $config = self::getModuleConfig();
        
        if (empty($config['turnstile_secret_key'])) {
            return true; // Skip if not configured
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://challenges.cloudflare.com/turnstile/v0/siteverify');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'secret' => $config['turnstile_secret_key'],
            'response' => $token,
            'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);

        return isset($result['success']) && $result['success'] === true;
    }

    /**
     * Get client IP address
     *
     * @return string
     */
    public static function getClientIp()
    {
        $headers = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];

        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                // Handle comma-separated IPs (X-Forwarded-For)
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}
