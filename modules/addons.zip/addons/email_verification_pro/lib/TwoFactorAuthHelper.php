<?php
/**
 * Email Verification Pro - Two-Factor Authentication Helper
 *
 * Handles email-based 2FA for login verification.
 *
 * @copyright 2026
 * @license Proprietary
 */

namespace WHMCS\Module\Addon\EmailVerificationPro;

use WHMCS\Database\Capsule;

class TwoFactorAuthHelper
{
    /**
     * Configuration cache
     */
    private static $configCache = null;

    /**
     * Get 2FA configuration
     *
     * @return array
     */
    public static function getConfig()
    {
        if (self::$configCache !== null) {
            return self::$configCache;
        }

        $settings = Capsule::table('tbladdonmodules')
            ->where('module', 'email_verification_pro')
            ->pluck('value', 'setting')
            ->toArray();

        self::$configCache = [
            'twofa_enabled' => ($settings['twofa_enabled'] ?? '') === 'on',
            'twofa_code_length' => (int) ($settings['twofa_code_length'] ?? 6),
            'twofa_code_expiry' => (int) ($settings['twofa_code_expiry'] ?? 10),
            'twofa_max_attempts' => (int) ($settings['twofa_max_attempts'] ?? 5),
            'twofa_lockout_duration' => (int) ($settings['twofa_lockout_duration'] ?? 30),
            'twofa_remember_device' => ($settings['twofa_remember_device'] ?? '') === 'on',
            'twofa_remember_days' => (int) ($settings['twofa_remember_days'] ?? 30),
            'twofa_require_for_admin' => ($settings['twofa_require_for_admin'] ?? '') === 'on',
            'twofa_exempt_ips' => $settings['twofa_exempt_ips'] ?? '',
            'twofa_code_type' => $settings['twofa_code_type'] ?? 'numeric',
        ];

        return self::$configCache;
    }

    /**
     * Check if 2FA is required for a client
     *
     * @param int $clientId
     * @return bool
     */
    public static function isRequired($clientId)
    {
        $config = self::getConfig();

        if (!$config['twofa_enabled']) {
            return false;
        }

        // Check if IP is exempt
        $ip = self::getClientIp();
        $exemptIps = array_filter(array_map('trim', explode("\n", $config['twofa_exempt_ips'])));
        if (in_array($ip, $exemptIps)) {
            return false;
        }

        // Check if device is remembered
        if ($config['twofa_remember_device'] && self::isDeviceRemembered($clientId)) {
            return false;
        }

        return true;
    }

    /**
     * Generate a verification code
     *
     * @param int $length
     * @param string $type 'numeric', 'alphanumeric', 'alpha'
     * @return string
     */
    public static function generateCode($length = null, $type = null)
    {
        $config = self::getConfig();
        $length = $length ?? $config['twofa_code_length'];
        $type = $type ?? $config['twofa_code_type'];

        switch ($type) {
            case 'alphanumeric':
                $chars = '0123456789ABCDEFGHJKLMNPQRSTUVWXYZ';
                break;
            case 'alpha':
                $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
                break;
            case 'numeric':
            default:
                $chars = '0123456789';
                break;
        }

        $code = '';
        $max = strlen($chars) - 1;
        for ($i = 0; $i < $length; $i++) {
            $code .= $chars[random_int(0, $max)];
        }

        return $code;
    }

    /**
     * Create a 2FA code for a client
     *
     * @param int $clientId
     * @param string $email
     * @return string The generated code
     */
    public static function createCode($clientId, $email)
    {
        $config = self::getConfig();
        $code = self::generateCode();
        $expiryMinutes = $config['twofa_code_expiry'];

        // Delete any existing codes for this client
        Capsule::table('mod_evp_twofa_codes')
            ->where('client_id', $clientId)
            ->delete();

        // Create new code
        Capsule::table('mod_evp_twofa_codes')->insert([
            'client_id' => $clientId,
            'email' => strtolower($email),
            'code' => password_hash($code, PASSWORD_DEFAULT),
            'plain_code' => $code, // For display in admin if needed
            'attempts' => 0,
            'created_at' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', strtotime("+{$expiryMinutes} minutes")),
            'ip_address' => self::getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        ]);

        // Log action
        EmailVerificationHelper::logAction($clientId, $email, '2fa_code_created', self::getClientIp());

        return $code;
    }

    /**
     * Send 2FA code via email
     *
     * @param int $clientId
     * @param string $code
     * @return bool
     */
    public static function sendCode($clientId, $code)
    {
        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
        if (!$client) {
            return false;
        }

        $config = self::getConfig();
        $expiryMinutes = $config['twofa_code_expiry'];

        // Get email template
        $template = EmailTemplateManager::getTemplate('2fa_code');
        
        // Replace placeholders
        $replacements = [
            '{client_name}' => $client->firstname,
            '{client_email}' => $client->email,
            '{verification_code}' => $code,
            '{code_expiry}' => $expiryMinutes,
            '{ip_address}' => self::getClientIp(),
            '{browser}' => self::getBrowserName(),
            '{timestamp}' => date('M j, Y H:i:s'),
        ];

        $subject = str_replace(array_keys($replacements), array_values($replacements), $template['subject']);
        $body = str_replace(array_keys($replacements), array_values($replacements), $template['body']);

        // Send email
        if (function_exists('localAPI')) {
            $result = localAPI('SendEmail', [
                'messagename' => 'General Messages',
                'id' => $clientId,
                'customtype' => 'general',
                'customsubject' => $subject,
                'custommessage' => $body,
            ]);
            return $result['result'] === 'success';
        }

        return false;
    }

    /**
     * Verify a 2FA code
     *
     * @param int $clientId
     * @param string $inputCode
     * @return array
     */
    public static function verifyCode($clientId, $inputCode)
    {
        $config = self::getConfig();
        $maxAttempts = $config['twofa_max_attempts'];
        $lockoutDuration = $config['twofa_lockout_duration'];

        $record = Capsule::table('mod_evp_twofa_codes')
            ->where('client_id', $clientId)
            ->first();

        if (!$record) {
            return ['success' => false, 'error' => 'No verification code found. Please request a new one.'];
        }

        // Check if expired
        if (strtotime($record->expires_at) < time()) {
            return ['success' => false, 'error' => 'Verification code has expired. Please request a new one.', 'expired' => true];
        }

        // Check if locked out
        if ($record->attempts >= $maxAttempts) {
            $lockedUntil = strtotime($record->updated_at ?? $record->created_at) + ($lockoutDuration * 60);
            if (time() < $lockedUntil) {
                $waitMinutes = ceil(($lockedUntil - time()) / 60);
                return ['success' => false, 'error' => "Too many attempts. Please wait {$waitMinutes} minutes.", 'locked' => true];
            } else {
                // Reset attempts after lockout
                Capsule::table('mod_evp_twofa_codes')
                    ->where('client_id', $clientId)
                    ->update(['attempts' => 0, 'updated_at' => date('Y-m-d H:i:s')]);
                $record->attempts = 0;
            }
        }

        // Verify code
        if (password_verify(strtoupper($inputCode), $record->code) || strtoupper($inputCode) === strtoupper($record->plain_code)) {
            // Success - delete the code
            Capsule::table('mod_evp_twofa_codes')
                ->where('client_id', $clientId)
                ->delete();

            // Remember device if enabled
            if ($config['twofa_remember_device']) {
                self::rememberDevice($clientId);
            }

            // Log success
            EmailVerificationHelper::logAction($clientId, $record->email, '2fa_verified', self::getClientIp());

            return ['success' => true];
        }

        // Increment attempts
        Capsule::table('mod_evp_twofa_codes')
            ->where('client_id', $clientId)
            ->update([
                'attempts' => $record->attempts + 1,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

        $remainingAttempts = $maxAttempts - $record->attempts - 1;

        // Log failed attempt
        EmailVerificationHelper::logAction($clientId, $record->email, '2fa_failed', self::getClientIp(), "Attempt " . ($record->attempts + 1));

        return [
            'success' => false,
            'error' => 'Invalid verification code. ' . ($remainingAttempts > 0 ? "{$remainingAttempts} attempts remaining." : 'You will be locked out.'),
            'remaining' => $remainingAttempts,
        ];
    }

    /**
     * Remember a device for future logins
     *
     * @param int $clientId
     */
    public static function rememberDevice($clientId)
    {
        $config = self::getConfig();
        $days = $config['twofa_remember_days'];
        $token = bin2hex(random_bytes(32));
        $hashedToken = hash('sha256', $token);

        // Store in database
        Capsule::table('mod_evp_remembered_devices')->insert([
            'client_id' => $clientId,
            'device_token' => $hashedToken,
            'ip_address' => self::getClientIp(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', strtotime("+{$days} days")),
        ]);

        // Set cookie
        $expiry = time() + ($days * 24 * 60 * 60);
        setcookie('evp_device_token', $token, $expiry, '/', '', true, true);
    }

    /**
     * Check if device is remembered
     *
     * @param int $clientId
     * @return bool
     */
    public static function isDeviceRemembered($clientId)
    {
        if (!isset($_COOKIE['evp_device_token'])) {
            return false;
        }

        $token = $_COOKIE['evp_device_token'];
        $hashedToken = hash('sha256', $token);

        $device = Capsule::table('mod_evp_remembered_devices')
            ->where('client_id', $clientId)
            ->where('device_token', $hashedToken)
            ->where('expires_at', '>', date('Y-m-d H:i:s'))
            ->first();

        return $device !== null;
    }

    /**
     * Clear remembered devices for a client
     *
     * @param int $clientId
     */
    public static function clearRememberedDevices($clientId)
    {
        Capsule::table('mod_evp_remembered_devices')
            ->where('client_id', $clientId)
            ->delete();
    }

    /**
     * Get client IP address
     *
     * @return string
     */
    public static function getClientIp()
    {
        $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = explode(',', $_SERVER[$header])[0];
                if (filter_var(trim($ip), FILTER_VALIDATE_IP)) {
                    return trim($ip);
                }
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    /**
     * Get browser name from user agent
     *
     * @return string
     */
    public static function getBrowserName()
    {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        if (strpos($userAgent, 'Firefox') !== false) return 'Firefox';
        if (strpos($userAgent, 'Chrome') !== false) return 'Chrome';
        if (strpos($userAgent, 'Safari') !== false) return 'Safari';
        if (strpos($userAgent, 'Edge') !== false) return 'Edge';
        if (strpos($userAgent, 'Opera') !== false) return 'Opera';
        if (strpos($userAgent, 'MSIE') !== false || strpos($userAgent, 'Trident') !== false) return 'Internet Explorer';
        
        return 'Unknown Browser';
    }

    /**
     * Clean up expired codes and devices
     */
    public static function cleanup()
    {
        // Delete expired codes
        Capsule::table('mod_evp_twofa_codes')
            ->where('expires_at', '<', date('Y-m-d H:i:s'))
            ->delete();

        // Delete expired remembered devices
        Capsule::table('mod_evp_remembered_devices')
            ->where('expires_at', '<', date('Y-m-d H:i:s'))
            ->delete();
    }

    /**
     * Get 2FA statistics
     *
     * @return array
     */
    public static function getStatistics()
    {
        $today = date('Y-m-d');
        $week = date('Y-m-d', strtotime('-7 days'));

        return [
            'codes_sent_today' => Capsule::table('mod_email_verification_log')
                ->where('action', '2fa_code_created')
                ->whereDate('created_at', $today)
                ->count(),
            'codes_verified_today' => Capsule::table('mod_email_verification_log')
                ->where('action', '2fa_verified')
                ->whereDate('created_at', $today)
                ->count(),
            'failed_attempts_today' => Capsule::table('mod_email_verification_log')
                ->where('action', '2fa_failed')
                ->whereDate('created_at', $today)
                ->count(),
            'remembered_devices' => Capsule::table('mod_evp_remembered_devices')
                ->where('expires_at', '>', date('Y-m-d H:i:s'))
                ->count(),
            'pending_codes' => Capsule::table('mod_evp_twofa_codes')
                ->where('expires_at', '>', date('Y-m-d H:i:s'))
                ->count(),
        ];
    }
}
