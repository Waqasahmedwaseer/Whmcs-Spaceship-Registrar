<?php
/**
 * Email Verification Pro - Email Template Manager
 *
 * Manages customizable email templates for the module.
 *
 * @copyright 2026
 * @license Proprietary
 */

namespace WHMCS\Module\Addon\EmailVerificationPro;

use WHMCS\Database\Capsule;

class EmailTemplateManager
{
    /**
     * Default email templates
     */
    private static $defaultTemplates = [
        'verification_email' => [
            'name' => 'Email Verification',
            'subject' => 'Please Verify Your Email Address',
            'body' => '
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0; font-size: 24px;">Email Verification Required</h1>
    </div>
    <div style="padding: 30px; background: #ffffff; border: 1px solid #eee;">
        <p style="font-size: 16px;">Hello <strong>{client_name}</strong>,</p>
        <p>Thank you for registering with us. To complete your registration and access your account, please verify your email address by clicking the button below:</p>
        <div style="text-align: center; margin: 30px 0;">
            <a href="{verification_link}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 30px; font-weight: bold; display: inline-block; font-size: 16px;">Verify My Email</a>
        </div>
        <p style="color: #666; font-size: 14px;">Or copy and paste this link into your browser:</p>
        <p style="background: #f5f5f5; padding: 15px; word-break: break-all; font-size: 12px; border-radius: 5px; color: #333;">{verification_link}</p>
        <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">
            <strong>⏰ This link will expire in {link_expiry} hours.</strong>
        </div>
        <p style="color: #999; font-size: 13px;">If you did not create an account, please ignore this email.</p>
    </div>
    <div style="padding: 20px; text-align: center; color: #666; font-size: 12px; background: #f9f9f9; border-radius: 0 0 10px 10px;">
        <p style="margin: 0;">This is an automated message. Please do not reply directly to this email.</p>
    </div>
</div>',
            'variables' => '{client_name}, {client_email}, {verification_link}, {link_expiry}',
        ],
        
        '2fa_code' => [
            'name' => 'Two-Factor Authentication Code',
            'subject' => 'Your Login Verification Code: {verification_code}',
            'body' => '
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0; font-size: 24px;">🔐 Login Verification</h1>
    </div>
    <div style="padding: 30px; background: #ffffff; border: 1px solid #eee;">
        <p style="font-size: 16px;">Hello <strong>{client_name}</strong>,</p>
        <p>A login attempt was detected for your account. Use the verification code below to complete your login:</p>
        <div style="text-align: center; margin: 30px 0;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px 50px; border-radius: 10px; display: inline-block;">
                <span style="font-size: 36px; font-weight: bold; letter-spacing: 8px;">{verification_code}</span>
            </div>
        </div>
        <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">
            <strong>⏰ This code will expire in {code_expiry} minutes.</strong>
        </div>
        <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin-top: 20px;">
            <p style="margin: 0 0 10px 0; font-weight: bold; color: #333;">Login Details:</p>
            <p style="margin: 5px 0; color: #666; font-size: 13px;">📍 IP Address: {ip_address}</p>
            <p style="margin: 5px 0; color: #666; font-size: 13px;">🌐 Browser: {browser}</p>
            <p style="margin: 5px 0; color: #666; font-size: 13px;">🕐 Time: {timestamp}</p>
        </div>
        <div style="background: #f8d7da; border-left: 4px solid #dc3545; padding: 15px; margin: 20px 0;">
            <strong style="color: #721c24;">⚠️ If you did not attempt to log in, please change your password immediately and contact support.</strong>
        </div>
    </div>
    <div style="padding: 20px; text-align: center; color: #666; font-size: 12px; background: #f9f9f9; border-radius: 0 0 10px 10px;">
        <p style="margin: 0;">Never share this code with anyone. Our staff will never ask for your verification code.</p>
    </div>
</div>',
            'variables' => '{client_name}, {verification_code}, {code_expiry}, {ip_address}, {browser}, {timestamp}',
        ],
        
        'verification_reminder' => [
            'name' => 'Verification Reminder',
            'subject' => 'Reminder: Please Verify Your Email Address',
            'body' => '
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0; font-size: 24px;">📧 Verification Reminder</h1>
    </div>
    <div style="padding: 30px; background: #ffffff; border: 1px solid #eee;">
        <p style="font-size: 16px;">Hello <strong>{client_name}</strong>,</p>
        <p>We noticed you haven\'t verified your email address yet. Your account access may be limited until verification is complete.</p>
        <p>Please click the button below to verify your email:</p>
        <div style="text-align: center; margin: 30px 0;">
            <a href="{verification_link}" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 30px; font-weight: bold; display: inline-block; font-size: 16px;">Verify Now</a>
        </div>
        <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">
            <strong>⚠️ If you don\'t verify within {days_remaining} days, your account may be suspended.</strong>
        </div>
    </div>
    <div style="padding: 20px; text-align: center; color: #666; font-size: 12px; background: #f9f9f9; border-radius: 0 0 10px 10px;">
        <p style="margin: 0;">Need help? Contact our support team.</p>
    </div>
</div>',
            'variables' => '{client_name}, {verification_link}, {days_remaining}',
        ],
        
        'account_termination_warning' => [
            'name' => 'Account Termination Warning',
            'subject' => 'Final Warning: Your Account Will Be Closed',
            'body' => '
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0; font-size: 24px;">⚠️ Urgent: Account Termination Warning</h1>
    </div>
    <div style="padding: 30px; background: #ffffff; border: 1px solid #eee;">
        <p style="font-size: 16px;">Hello <strong>{client_name}</strong>,</p>
        <p><strong style="color: #dc3545;">Your account will be terminated in {hours_remaining} hours due to unverified email address.</strong></p>
        <p>Please verify your email immediately to keep your account active:</p>
        <div style="text-align: center; margin: 30px 0;">
            <a href="{verification_link}" style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 30px; font-weight: bold; display: inline-block; font-size: 16px;">Verify Now - Save My Account</a>
        </div>
        <div style="background: #f8d7da; border-left: 4px solid #dc3545; padding: 15px; margin: 20px 0;">
            <strong style="color: #721c24;">After termination, all your data may be permanently deleted and cannot be recovered.</strong>
        </div>
    </div>
    <div style="padding: 20px; text-align: center; color: #666; font-size: 12px; background: #f9f9f9; border-radius: 0 0 10px 10px;">
        <p style="margin: 0;">If you believe this is an error, please contact support immediately.</p>
    </div>
</div>',
            'variables' => '{client_name}, {verification_link}, {hours_remaining}',
        ],
        
        'verification_success' => [
            'name' => 'Verification Success',
            'subject' => '✅ Email Verified Successfully!',
            'body' => '
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0; font-size: 24px;">✅ Email Verified!</h1>
    </div>
    <div style="padding: 30px; background: #ffffff; border: 1px solid #eee;">
        <p style="font-size: 16px;">Hello <strong>{client_name}</strong>,</p>
        <p>Great news! Your email address has been successfully verified.</p>
        <p>You now have full access to your account and all its features.</p>
        <div style="text-align: center; margin: 30px 0;">
            <a href="{client_area_link}" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 30px; font-weight: bold; display: inline-block; font-size: 16px;">Go to My Account</a>
        </div>
        <div style="background: #d4edda; border-left: 4px solid #28a745; padding: 15px; margin: 20px 0;">
            <strong style="color: #155724;">🎉 Welcome aboard! Thank you for choosing us.</strong>
        </div>
    </div>
    <div style="padding: 20px; text-align: center; color: #666; font-size: 12px; background: #f9f9f9; border-radius: 0 0 10px 10px;">
        <p style="margin: 0;">Thank you for your business!</p>
    </div>
</div>',
            'variables' => '{client_name}, {client_area_link}',
        ],

        'new_device_login' => [
            'name' => 'New Device Login Alert',
            'subject' => '🔔 New Login Detected on Your Account',
            'body' => '
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0; font-size: 24px;">🔔 New Login Detected</h1>
    </div>
    <div style="padding: 30px; background: #ffffff; border: 1px solid #eee;">
        <p style="font-size: 16px;">Hello <strong>{client_name}</strong>,</p>
        <p>A new login was detected on your account from a new device or location:</p>
        <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0;">
            <p style="margin: 5px 0;"><strong>📍 IP Address:</strong> {ip_address}</p>
            <p style="margin: 5px 0;"><strong>🌐 Browser:</strong> {browser}</p>
            <p style="margin: 5px 0;"><strong>📍 Location:</strong> {location}</p>
            <p style="margin: 5px 0;"><strong>🕐 Time:</strong> {timestamp}</p>
        </div>
        <p><strong>Was this you?</strong></p>
        <p>If this was you, you can safely ignore this email. If you don\'t recognize this activity, please:</p>
        <ul>
            <li>Change your password immediately</li>
            <li>Review your recent account activity</li>
            <li>Contact our support team</li>
        </ul>
    </div>
    <div style="padding: 20px; text-align: center; color: #666; font-size: 12px; background: #f9f9f9; border-radius: 0 0 10px 10px;">
        <p style="margin: 0;">This is a security alert from your account.</p>
    </div>
</div>',
            'variables' => '{client_name}, {ip_address}, {browser}, {location}, {timestamp}',
        ],

        'suspicious_activity' => [
            'name' => 'Suspicious Activity Alert',
            'subject' => '⚠️ Suspicious Activity Detected on Your Account',
            'body' => '
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <div style="background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
        <h1 style="margin: 0; font-size: 24px;">⚠️ Security Alert</h1>
    </div>
    <div style="padding: 30px; background: #ffffff; border: 1px solid #eee;">
        <p style="font-size: 16px;">Hello <strong>{client_name}</strong>,</p>
        <p><strong style="color: #dc3545;">We detected suspicious activity on your account:</strong></p>
        <div style="background: #f8d7da; padding: 20px; border-radius: 10px; margin: 20px 0; border-left: 4px solid #dc3545;">
            <p style="margin: 5px 0; color: #721c24;"><strong>Activity:</strong> {activity_type}</p>
            <p style="margin: 5px 0; color: #721c24;"><strong>Details:</strong> {activity_details}</p>
            <p style="margin: 5px 0; color: #721c24;"><strong>Time:</strong> {timestamp}</p>
        </div>
        <p><strong>Recommended Actions:</strong></p>
        <ol>
            <li>Change your password immediately</li>
            <li>Review your recent account activity</li>
            <li>Enable additional security features</li>
            <li>Contact our support if you notice any unauthorized changes</li>
        </ol>
    </div>
    <div style="padding: 20px; text-align: center; color: #666; font-size: 12px; background: #f9f9f9; border-radius: 0 0 10px 10px;">
        <p style="margin: 0;">If you did not perform these actions, contact support immediately.</p>
    </div>
</div>',
            'variables' => '{client_name}, {activity_type}, {activity_details}, {timestamp}',
        ],
    ];

    /**
     * Initialize email templates table
     */
    public static function initialize()
    {
        // Create table if not exists
        if (!Capsule::schema()->hasTable('mod_evp_email_templates')) {
            Capsule::schema()->create('mod_evp_email_templates', function ($table) {
                $table->increments('id');
                $table->string('template_key', 50)->unique();
                $table->string('name', 100);
                $table->string('subject', 255);
                $table->text('body');
                $table->text('variables')->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->nullable();
            });

            // Insert default templates
            foreach (self::$defaultTemplates as $key => $template) {
                Capsule::table('mod_evp_email_templates')->insert([
                    'template_key' => $key,
                    'name' => $template['name'],
                    'subject' => $template['subject'],
                    'body' => $template['body'],
                    'variables' => $template['variables'],
                    'is_active' => true,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }
    }

    /**
     * Get an email template
     *
     * @param string $key
     * @return array
     */
    public static function getTemplate($key)
    {
        $template = Capsule::table('mod_evp_email_templates')
            ->where('template_key', $key)
            ->first();

        if ($template) {
            return [
                'name' => $template->name,
                'subject' => $template->subject,
                'body' => $template->body,
                'variables' => $template->variables,
                'is_active' => $template->is_active,
            ];
        }

        // Return default if not found
        if (isset(self::$defaultTemplates[$key])) {
            return self::$defaultTemplates[$key];
        }

        return [
            'name' => 'Unknown Template',
            'subject' => 'Notification',
            'body' => 'No template content.',
            'variables' => '',
            'is_active' => true,
        ];
    }

    /**
     * Get all templates
     *
     * @return array
     */
    public static function getAllTemplates()
    {
        return Capsule::table('mod_evp_email_templates')
            ->orderBy('name')
            ->get()
            ->toArray();
    }

    /**
     * Update a template
     *
     * @param string $key
     * @param array $data
     * @return bool
     */
    public static function updateTemplate($key, $data)
    {
        return Capsule::table('mod_evp_email_templates')
            ->where('template_key', $key)
            ->update([
                'name' => $data['name'] ?? '',
                'subject' => $data['subject'] ?? '',
                'body' => $data['body'] ?? '',
                'is_active' => $data['is_active'] ?? true,
                'updated_at' => date('Y-m-d H:i:s'),
            ]) > 0;
    }

    /**
     * Reset a template to default
     *
     * @param string $key
     * @return bool
     */
    public static function resetTemplate($key)
    {
        if (!isset(self::$defaultTemplates[$key])) {
            return false;
        }

        $default = self::$defaultTemplates[$key];

        return Capsule::table('mod_evp_email_templates')
            ->where('template_key', $key)
            ->update([
                'name' => $default['name'],
                'subject' => $default['subject'],
                'body' => $default['body'],
                'variables' => $default['variables'],
                'updated_at' => date('Y-m-d H:i:s'),
            ]) > 0;
    }

    /**
     * Reset all templates to default
     *
     * @return int Number of templates reset
     */
    public static function resetAllTemplates()
    {
        $count = 0;
        foreach (self::$defaultTemplates as $key => $template) {
            if (self::resetTemplate($key)) {
                $count++;
            }
        }
        return $count;
    }

    /**
     * Send an email using a template
     *
     * @param string $templateKey
     * @param int $clientId
     * @param array $replacements Key-value pairs for variable replacement
     * @return bool
     */
    public static function sendEmail($templateKey, $clientId, $replacements = [])
    {
        $template = self::getTemplate($templateKey);

        if (!$template['is_active']) {
            return false;
        }

        // Replace variables
        $subject = $template['subject'];
        $body = $template['body'];

        foreach ($replacements as $key => $value) {
            $subject = str_replace($key, $value, $subject);
            $body = str_replace($key, $value, $body);
        }

        // Send email via WHMCS
        if (function_exists('localAPI')) {
            $result = localAPI('SendEmail', [
                'messagename' => 'General Messages',
                'id' => $clientId,
                'customtype' => 'general',
                'customsubject' => $subject,
                'custommessage' => $body,
            ]);
            return $result['result'] === 'success';
        }

        return false;
    }

    /**
     * Preview a template with sample data
     *
     * @param string $key
     * @return array
     */
    public static function previewTemplate($key)
    {
        $template = self::getTemplate($key);

        $sampleData = [
            '{client_name}' => 'John Doe',
            '{client_email}' => 'john@example.com',
            '{verification_link}' => 'https://example.com/verify?token=abc123xyz',
            '{verification_code}' => '847291',
            '{link_expiry}' => '48',
            '{code_expiry}' => '10',
            '{ip_address}' => '192.168.1.100',
            '{browser}' => 'Chrome on Windows',
            '{location}' => 'New York, United States',
            '{timestamp}' => date('M j, Y H:i:s'),
            '{days_remaining}' => '3',
            '{hours_remaining}' => '24',
            '{client_area_link}' => 'https://example.com/clientarea.php',
            '{activity_type}' => 'Multiple failed login attempts',
            '{activity_details}' => '5 failed login attempts from different IP addresses',
        ];

        $subject = $template['subject'];
        $body = $template['body'];

        foreach ($sampleData as $key => $value) {
            $subject = str_replace($key, $value, $subject);
            $body = str_replace($key, $value, $body);
        }

        return [
            'subject' => $subject,
            'body' => $body,
        ];
    }
}
