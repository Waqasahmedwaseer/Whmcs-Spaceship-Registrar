<?php
/**
 * Spaceship.com Domain Registrar Module for WHMCS
 *
 * This module integrates Spaceship.com's domain registration API with WHMCS,
 * providing full domain management capabilities including registration,
 * transfers, renewals, DNS management, and more.
 *
 * @copyright 2026
 * @license MIT
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Domains\DomainLookup\ResultsList;
use WHMCS\Domains\DomainLookup\SearchResult;
use WHMCS\Module\Registrar\Spaceship\ApiClient;

// Require the API client
require_once __DIR__ . '/lib/ApiClient.php';

/**
 * Define module related metadata
 *
 * @return array
 */
function spaceship_MetaData()
{
    return [
        'DisplayName' => 'Spaceship.com Domain Registrar',
        'APIVersion' => '1.1',
    ];
}

/**
 * Define registrar configuration options.
 *
 * @return array
 */
function spaceship_getConfigArray()
{
    return [
        'FriendlyName' => [
            'Type' => 'System',
            'Value' => 'Spaceship.com Domain Registrar',
        ],
        'APIKey' => [
            'FriendlyName' => 'API Key',
            'Type' => 'text',
            'Size' => '50',
            'Default' => '',
            'Description' => 'Enter your Spaceship API Key from the API Manager',
        ],
        'APISecret' => [
            'FriendlyName' => 'API Secret',
            'Type' => 'password',
            'Size' => '50',
            'Default' => '',
            'Description' => 'Enter your Spaceship API Secret',
        ],
        'TestMode' => [
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Enable this to use the sandbox/test API endpoint',
        ],
        'DefaultPrivacyProtection' => [
            'FriendlyName' => 'Default Privacy Protection',
            'Type' => 'dropdown',
            'Options' => [
                'high' => 'High (Full Privacy)',
                'low' => 'Low (Partial Privacy)',
                'off' => 'Off (No Privacy)',
            ],
            'Default' => 'high',
            'Description' => 'Default privacy protection level for new registrations',
        ],
        'DefaultAutoRenew' => [
            'FriendlyName' => 'Default Auto Renew',
            'Type' => 'yesno',
            'Description' => 'Enable auto-renewal by default for new registrations',
        ],
        'DebugMode' => [
            'FriendlyName' => 'Debug Mode',
            'Type' => 'yesno',
            'Description' => 'Enable detailed logging for troubleshooting',
        ],
        'EnableRealtimeSync' => [
            'FriendlyName' => 'Enable Realtime Sync View',
            'Type' => 'yesno',
            'Description' => 'When viewing a domain in the admin area, this will display the current live data from the registrar. (Does not automatically save)',
        ],
    ];
}

/**
 * Register a domain.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_RegisterDomain($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $registrationPeriod = $params['regperiod'];

    // Privacy protection settings
    $enableIdProtection = (bool) $params['idprotection'];
    $privacyLevel = $enableIdProtection ? ($params['DefaultPrivacyProtection'] ?: 'high') : 'off';

    // Auto-renew setting
    $autoRenew = (bool) $params['DefaultAutoRenew'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        // First, create contact for registrant
        $registrantContactId = spaceship_createContact($api, $params, 'registrant');
        $adminContactId = spaceship_createContact($api, $params, 'admin');
        $techContactId = spaceship_createContact($api, $params, 'tech');
        $billingContactId = spaceship_createContact($api, $params, 'billing');

        // Register the domain
        $registrationPayload = [
            'autoRenew' => $autoRenew,
            'years' => (int) $registrationPeriod,
            'privacyProtection' => [
                'level' => $privacyLevel,
                'userConsent' => true,
            ],
            'contacts' => [
                'registrant' => $registrantContactId,
                'admin' => $adminContactId,
                'tech' => $techContactId,
                'billing' => $billingContactId,
            ],
        ];

        // Set nameservers if provided directly in the registration payload
        $nameservers = array_filter([
            $params['ns1'],
            $params['ns2'],
            $params['ns3'],
            $params['ns4'],
            $params['ns5'],
        ]);

        if (!empty($nameservers)) {
            $registrationPayload['nameServers'] = [
                'provider' => 'custom',
                'hosts' => $nameservers,
            ];
        }

        $response = $api->post("/v1/domains/{$domain}", $registrationPayload);

        // Domain registration is async, check for operation ID
        $operationId = $api->getAsyncOperationId();
        if ($operationId) {
            // Poll for completion or store for later sync
            $operationResult = $api->waitForAsyncOperation($operationId);
            if ($operationResult['status'] === 'failed') {
                throw new \Exception('Domain registration failed: ' . ($operationResult['details']['message'] ?? 'Unknown error'));
            }
        }

        return ['success' => true];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Initiate domain transfer.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_TransferDomain($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $eppCode = $params['eppcode'];

    // Privacy protection settings
    $enableIdProtection = (bool) $params['idprotection'];
    $privacyLevel = $enableIdProtection ? ($params['DefaultPrivacyProtection'] ?: 'high') : 'off';

    // Auto-renew setting
    $autoRenew = (bool) $params['DefaultAutoRenew'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        // Create contacts for transfer
        $registrantContactId = spaceship_createContact($api, $params, 'registrant');
        $adminContactId = spaceship_createContact($api, $params, 'admin');
        $techContactId = spaceship_createContact($api, $params, 'tech');
        $billingContactId = spaceship_createContact($api, $params, 'billing');

        // Initiate domain transfer
        $response = $api->post("/v1/domains/{$domain}/transfer", [
            'autoRenew' => $autoRenew,
            'privacyProtection' => [
                'level' => $privacyLevel,
                'userConsent' => true,
            ],
            'contacts' => [
                'registrant' => $registrantContactId,
                'admin' => $adminContactId,
                'tech' => $techContactId,
                'billing' => $billingContactId,
            ],
            'authCode' => $eppCode,
        ]);

        $operationId = $api->getAsyncOperationId();
        if ($operationId) {
            // Transfer is async, store operation ID for later sync if needed
            logModuleCall('Spaceship', 'TransferDomain', $domain, "Async operation started: {$operationId}");
        }

        return ['success' => true];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Renew a domain.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_RenewDomain($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $registrationPeriod = $params['regperiod'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $response = $api->post("/v1/domains/{$domain}/renew", [
            'years' => (int) $registrationPeriod,
        ]);

        $operationId = $api->getAsyncOperationId();
        if ($operationId) {
            $operationResult = $api->waitForAsyncOperation($operationId);
            if ($operationResult['status'] === 'failed') {
                throw new \Exception('Domain renewal failed: ' . ($operationResult['details']['message'] ?? 'Unknown error'));
            }
        }

        return ['success' => true];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Fetch current nameservers.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_GetNameservers($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);
        $response = $api->get("/v1/domains/{$domain}");

        $nameservers = [];
        if (isset($response['nameServers']['hosts']) && is_array($response['nameServers']['hosts'])) {
            foreach ($response['nameServers']['hosts'] as $index => $ns) {
                $nameservers['ns' . ($index + 1)] = $ns;
            }
        }

        return $nameservers;

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Save nameserver changes.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_SaveNameservers($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    $nameservers = array_filter([
        $params['ns1'],
        $params['ns2'],
        $params['ns3'],
        $params['ns4'],
        $params['ns5'],
    ]);

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $api->put("/v1/domains/{$domain}/nameservers", [
            'provider' => 'custom',
            'hosts' => array_values($nameservers),
        ]);

        return ['success' => true];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Get the current WHOIS Contact Information.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_GetContactDetails($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);
        $domainInfo = $api->get("/v1/domains/{$domain}");

        $contacts = [];
        $contactTypes = ['registrant', 'admin', 'tech', 'billing'];

        foreach ($contactTypes as $type) {
            $contactId = $domainInfo['contacts'][$type] ?? null;
            if ($contactId) {
                $contactDetails = $api->get("/v1/contacts/{$contactId}");
                $contacts[ucfirst($type)] = [
                    'First Name' => $contactDetails['firstName'] ?? '',
                    'Last Name' => $contactDetails['lastName'] ?? '',
                    'Company Name' => $contactDetails['organization'] ?? '',
                    'Email Address' => $contactDetails['email'] ?? '',
                    'Address 1' => $contactDetails['address1'] ?? '',
                    'Address 2' => $contactDetails['address2'] ?? '',
                    'City' => $contactDetails['city'] ?? '',
                    'State' => $contactDetails['stateProvince'] ?? '',
                    'Postcode' => $contactDetails['postalCode'] ?? '',
                    'Country' => $contactDetails['country'] ?? '',
                    'Phone Number' => $contactDetails['phone'] ?? '',
                    'Fax Number' => $contactDetails['fax'] ?? '',
                ];
            }
        }

        return $contacts;

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Update the WHOIS Contact Information for a given domain.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_SaveContactDetails($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    $contactDetails = $params['contactdetails'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $contactIds = [];
        $contactTypes = ['Registrant', 'Admin', 'Tech', 'Billing'];

        foreach ($contactTypes as $type) {
            if (isset($contactDetails[$type])) {
                $contact = $contactDetails[$type];
                $response = $api->put('/v1/contacts', [
                    'firstName' => $contact['First Name'] ?? '',
                    'lastName' => $contact['Last Name'] ?? '',
                    'organization' => $contact['Company Name'] ?? '',
                    'email' => $contact['Email Address'] ?? '',
                    'address1' => $contact['Address 1'] ?? '',
                    'address2' => $contact['Address 2'] ?? '',
                    'city' => $contact['City'] ?? '',
                    'stateProvince' => $contact['State'] ?? '',
                    'postalCode' => $contact['Postcode'] ?? '',
                    'country' => $contact['Country'] ?? '',
                    'phone' => $contact['Phone Number'] ?? '',
                    'fax' => $contact['Fax Number'] ?? '',
                ]);
                $contactIds[strtolower($type)] = $response['contactId'] ?? '';
            }
        }

        // Update domain contacts
        $api->put("/v1/domains/{$domain}/contacts", $contactIds);

        return ['success' => true];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Check Domain Availability.
 *
 * @param array $params common module parameters
 * @return \WHMCS\Domains\DomainLookup\ResultsList
 */
function spaceship_CheckAvailability($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $searchTerm = $params['searchTerm'];
    $punyCodeSearchTerm = $params['punyCodeSearchTerm'];
    $tldsToInclude = $params['tldsToInclude'];
    $premiumEnabled = (bool) $params['premiumEnabled'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $domains = [];
        foreach ($tldsToInclude as $tld) {
            $domains[] = $punyCodeSearchTerm . '.' . $tld;
        }

        $response = $api->post('/v1/domains/available', [
            'domains' => $domains,
        ]);

        $results = new ResultsList();

        foreach ($response['items'] ?? [] as $domainResult) {
            $domainName = $domainResult['domain'] ?? '';
            $parts = explode('.', $domainName, 2);
            $sld = $parts[0] ?? '';
            $tld = $parts[1] ?? '';

            $searchResult = new SearchResult($sld, $tld);

            $availability = $domainResult['availability'] ?? '';
            switch ($availability) {
                case 'available':
                    $status = SearchResult::STATUS_NOT_REGISTERED;
                    break;
                case 'unavailable':
                case 'registered':
                    $status = SearchResult::STATUS_REGISTERED;
                    break;
                case 'reserved':
                    $status = SearchResult::STATUS_RESERVED;
                    break;
                default:
                    $status = SearchResult::STATUS_TLD_NOT_SUPPORTED;
            }
            $searchResult->setStatus($status);

            // Handle premium domains
            if ($premiumEnabled && isset($domainResult['pricing'])) {
                $pricing = $domainResult['pricing'];
                if (isset($pricing['premium']) && $pricing['premium']) {
                    $searchResult->setPremiumDomain(true);
                    $searchResult->setPremiumCostPricing([
                        'register' => $pricing['registerPrice'] ?? 0,
                        'renew' => $pricing['renewPrice'] ?? 0,
                        'CurrencyCode' => $pricing['currency'] ?? 'USD',
                    ]);
                }
            }

            $results->append($searchResult);
        }

        return $results;

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Get registrar lock status.
 *
 * @param array $params common module parameters
 * @return string|array Lock status or error message
 */
function spaceship_GetRegistrarLock($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);
        $response = $api->get("/v1/domains/{$domain}");

        $locks = $response['locks'] ?? [];
        $isLocked = in_array('clientTransferProhibited', $locks) || 
                    in_array('clientUpdateProhibited', $locks);

        return $isLocked ? 'locked' : 'unlocked';

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Set registrar lock status.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_SaveRegistrarLock($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $lockStatus = $params['lockenabled'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $api->put("/v1/domains/{$domain}/locks", [
            'isEnabled' => ($lockStatus === 'locked'),
        ]);

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Get DNS Records for DNS Host Record Management.
 *
 * @param array $params common module parameters
 * @return array DNS Host Records
 */
function spaceship_GetDNS($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);
        $response = $api->get("/v1/dns/records/{$domain}?take=100&skip=0");

        $hostRecords = [];
        foreach ($response['items'] ?? [] as $record) {
            $hostRecord = [
                'hostname' => $record['name'] ?? '@',
                'type' => $record['type'] ?? 'A',
                'address' => '',
                'priority' => '',
            ];

            // Map different record types
            switch ($record['type']) {
                case 'A':
                case 'AAAA':
                    $hostRecord['address'] = $record['address'] ?? '';
                    break;
                case 'CNAME':
                    $hostRecord['address'] = $record['cname'] ?? '';
                    break;
                case 'MX':
                    $hostRecord['address'] = $record['exchange'] ?? '';
                    $hostRecord['priority'] = $record['preference'] ?? '';
                    break;
                case 'TXT':
                    $hostRecord['address'] = $record['value'] ?? '';
                    break;
                case 'NS':
                    $hostRecord['address'] = $record['nameserver'] ?? '';
                    break;
                case 'SRV':
                    $hostRecord['address'] = $record['target'] ?? '';
                    $hostRecord['priority'] = $record['priority'] ?? '';
                    break;
            }

            $hostRecords[] = $hostRecord;
        }

        return $hostRecords;

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Update DNS Host Records.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_SaveDNS($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $dnsrecords = $params['dnsrecords'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $items = [];
        foreach ($dnsrecords as $record) {
            if (empty($record['hostname']) && empty($record['address'])) {
                continue;
            }

            $item = [
                'name' => $record['hostname'] ?: '@',
                'type' => $record['type'] ?? 'A',
                'ttl' => 3600,
            ];

            switch ($record['type']) {
                case 'A':
                case 'AAAA':
                    $item['address'] = $record['address'];
                    break;
                case 'CNAME':
                    $item['cname'] = $record['address'];
                    break;
                case 'MX':
                    $item['exchange'] = $record['address'];
                    $item['preference'] = (int) ($record['priority'] ?? 10);
                    break;
                case 'TXT':
                    $item['value'] = $record['address'];
                    break;
                case 'NS':
                    $item['nameserver'] = $record['address'];
                    break;
                case 'SRV':
                    $item['target'] = $record['address'];
                    $item['priority'] = (int) ($record['priority'] ?? 0);
                    break;
            }

            $items[] = $item;
        }

        if (!empty($items)) {
            $api->put("/v1/dns/records/{$domain}", [
                'force' => true,
                'items' => $items,
            ]);
        }

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Enable/Disable ID Protection (Privacy Protection).
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_IDProtectToggle($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $protectEnable = (bool) $params['protectenable'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $privacyLevel = $protectEnable ? 'high' : 'off';

        $api->put("/v1/domains/{$domain}/privacy-protection", [
            'level' => $privacyLevel,
            'userConsent' => true,
        ]);

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Request EPP Code.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_GetEPPCode($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);
        
        // First, try to get the existing auth code.
        $response = $api->get("/v1/domains/{$domain}/transfer/auth-code");
        $eppCode = $response['authCode'] ?? '';

        if ($eppCode) {
            return ['eppcode' => $eppCode];
        }
    } catch (\Exception $e) {
        // Log the error from the GET attempt for debugging.
        logModuleCall('spaceship', __FUNCTION__ . ' (GET)', "Attempting to get EPP code failed. Error: {$e->getMessage()}. Proceeding to generate a new one.", $e);
    }

    // If we're here, either the GET failed or it returned an empty code.
    // Let's try to generate a new one.
    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);
        $api->post("/v1/domains/{$domain}/transfer/auth-code", []);

        // The POST call is async (202). We return a success message to WHMCS
        // indicating the request was submitted.
        return ['success' => 'EPP Code generation has been requested. Please try again in a few moments.'];

    } catch (\Exception $e) {
        // If generating the code also fails, then we return the error.
        logModuleCall('spaceship', __FUNCTION__ . ' (POST)', "Attempting to generate EPP code also failed. Error: {$e->getMessage()}", $e);
        return ['error' => 'Failed to generate EPP code: ' . $e->getMessage()];
    }
}

/**
 * Register a Nameserver (Child/Glue record).
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_RegisterNameserver($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $nameserver = $params['nameserver'];
    $ipAddress = $params['ipaddress'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        // Extract host from full nameserver
        $host = str_replace('.' . $domain, '', $nameserver);

        $api->post("/v1/domains/{$domain}/personal-nameservers", [
            'host' => $host,
            'ipAddresses' => [$ipAddress],
        ]);

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Modify a Nameserver (Child/Glue record).
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_ModifyNameserver($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $nameserver = $params['nameserver'];
    $newIpAddress = $params['newipaddress'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        // Extract host from full nameserver
        $host = str_replace('.' . $domain, '', $nameserver);

        $api->put("/v1/domains/{$domain}/personal-nameservers/{$host}", [
            'host' => $host,
            'ipAddresses' => [$newIpAddress],
        ]);

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Delete a Nameserver (Child/Glue record).
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_DeleteNameserver($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $nameserver = $params['nameserver'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        // Extract host from full nameserver
        $host = str_replace('.' . $domain, '', $nameserver);

        $api->delete("/v1/domains/{$domain}/personal-nameservers/{$host}");

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Sync Domain Status & Expiration Date.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_Sync($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);
        $response = $api->get("/v1/domains/{$domain}");

        $expiryDate = $response['expirationDate'] ?? '';
        $status = $response['status'] ?? '';

        // Determine if domain is active
        $isActive = !in_array($status, ['expired', 'redemption', 'pendingDelete', 'deleted']);
        $isTransferredAway = ($status === 'transferredAway');

        // Format expiry date
        if ($expiryDate) {
            $expiryDate = date('Y-m-d', strtotime($expiryDate));
        }

        return [
            'expirydate' => $expiryDate,
            'active' => $isActive,
            'transferredAway' => $isTransferredAway,
        ];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Incoming Domain Transfer Sync.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_TransferSync($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);
        $response = $api->get("/v1/domains/{$domain}/transfer");

        $status = $response['status'] ?? '';

        switch ($status) {
            case 'completed':
                $domainInfo = $api->get("/v1/domains/{$domain}");
                $expiryDate = $domainInfo['expirationDate'] ?? '';
                if ($expiryDate) {
                    $expiryDate = date('Y-m-d', strtotime($expiryDate));
                }
                return [
                    'completed' => true,
                    'expirydate' => $expiryDate,
                ];

            case 'failed':
            case 'rejected':
                return [
                    'failed' => true,
                    'reason' => $response['failureReason'] ?? 'Transfer failed or was rejected',
                ];

            default:
                // Transfer still in progress
                return [];
        }

    } catch (\Exception $e) {
        // Domain not found might mean transfer not started yet
        return [];
    }
}

/**
 * Update domain auto-renewal setting.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_SaveAutorenew($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;
    $autoRenew = (bool) $params['autorenew'];

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $api->put("/v1/domains/{$domain}/autorenew", [
            'isEnabled' => $autoRenew,
        ]);

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Delete Domain (Request deletion).
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_RequestDelete($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $api->delete("/v1/domains/{$domain}");

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Restore Domain from Redemption.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_RestoreDomain($params)
{
    $apiKey = $params['APIKey'];
    $apiSecret = $params['APISecret'];
    $testMode = $params['TestMode'];

    $sld = $params['sld'];
    $tld = $params['tld'];
    $domain = $sld . '.' . $tld;

    try {
        $api = new ApiClient($apiKey, $apiSecret, $testMode);

        $response = $api->post("/v1/domains/{$domain}/restore", []);

        $operationId = $api->getAsyncOperationId();
        if ($operationId) {
            $operationResult = $api->waitForAsyncOperation($operationId);
            if ($operationResult['status'] === 'failed') {
                throw new \Exception('Domain restore failed: ' . ($operationResult['details']['message'] ?? 'Unknown error'));
            }
        }

        return ['success' => 'success'];

    } catch (\Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

/**
 * Client Area Custom Button Array.
 *
 * @return array
 */
function spaceship_ClientAreaCustomButtonArray()
{
    return [
        'Manage DNS' => 'manageDNS',
        'Privacy Settings' => 'privacySettings',
    ];
}

/**
 * Client Area Allowed Functions.
 *
 * @return array
 */
function spaceship_ClientAreaAllowedFunctions()
{
    return [
        'Manage DNS' => 'manageDNS',
        'Privacy Settings' => 'privacySettings',
    ];
}

/**
 * Helper function to create a contact in Spaceship.
 *
 * @param ApiClient $api
 * @param array $params
 * @param string $type (registrant, admin, tech, billing)
 * @return string Contact ID
 */
function spaceship_createContact($api, $params, $type)
{
    // Map WHMCS params to contact type prefixes
    $prefix = ($type === 'registrant') ? '' : $type;

    $firstName = $params[$prefix . 'firstname'] ?? $params['firstname'];
    $lastName = $params[$prefix . 'lastname'] ?? $params['lastname'];
    $companyName = $params[$prefix . 'companyname'] ?? $params['companyname'];
    $email = $params[$prefix . 'email'] ?? $params['email'];
    $address1 = $params[$prefix . 'address1'] ?? $params['address1'];
    $address2 = $params[$prefix . 'address2'] ?? $params['address2'];
    $city = $params[$prefix . 'city'] ?? $params['city'];
    $state = $params[$prefix . 'state'] ?? $params['state'];
    $postcode = $params[$prefix . 'postcode'] ?? $params['postcode'];
    $country = $params[$prefix . 'country'] ?? $params['countrycode'];
    $phone = $params[$prefix . 'fullphonenumber'] ?? $params['fullphonenumber'];

    $response = $api->put('/v1/contacts', [
        'firstName' => $firstName,
        'lastName' => $lastName,
        'organization' => $companyName ?: '',
        'email' => $email,
        'address1' => $address1,
        'address2' => $address2 ?: '',
        'city' => $city,
        'stateProvince' => $state,
        'postalCode' => $postcode,
        'country' => $country,
        'phone' => $phone,
    ]);

    return $response['contactId'] ?? '';
}

/**
 * Get TLD Pricing from Spaceship API (if available).
 * This is a supplementary function that can be used to sync pricing.
 *
 * @param array $params common module parameters
 * @return array
 */
function spaceship_GetTldPricing($params)
{
    // Note: Spaceship API may not have a dedicated pricing endpoint
    // This function is a placeholder for future implementation
    return [];
}

/**
 * Admin Area Custom Button Array.
 *
 * @return array
 */
function spaceship_AdminCustomButtonArray()
{
    return [
        'Sync Domain' => 'Sync',
        'Restore Domain' => 'RestoreDomain',
    ];
}

/**
 * Client Area Output.
 *
 * @param array $params common module parameters
 * @return string HTML Output
 */
function spaceship_ClientArea($params)
{
    $output = '
        <div class="alert alert-info">
            <strong>Spaceship.com Domain Management</strong><br>
            Your domain is registered with Spaceship.com. Use the controls above to manage your domain settings.
        </div>
    ';

    return $output;
}
