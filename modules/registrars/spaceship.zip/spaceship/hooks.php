<?php
/**
 * Spaceship.com Domain Registrar Module Hooks
 *
 * This file contains WHMCS hooks for the Spaceship.com domain registrar module.
 * Hooks allow the module to respond to various WHMCS events.
 *
 * @copyright 2026
 * @license MIT
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

/**
 * Hook: AfterRegistrarRegistration
 * Triggered after a domain registration is completed
 */
add_hook('AfterRegistrarRegistration', 1, function($vars) {
    // Only process Spaceship registrations
    if ($vars['params']['registrar'] !== 'spaceship') {
        return;
    }

    $domainId = $vars['params']['domainid'];
    $domain = $vars['params']['sld'] . '.' . $vars['params']['tld'];

    // Log successful registration
    logActivity("Spaceship: Domain {$domain} registered successfully");

    // Optional: Send custom email notification
    // sendMessage('Domain Registration Confirmation', $vars['params']['userid']);
});

/**
 * Hook: AfterRegistrarTransfer
 * Triggered after a domain transfer is initiated
 */
add_hook('AfterRegistrarTransfer', 1, function($vars) {
    if ($vars['params']['registrar'] !== 'spaceship') {
        return;
    }

    $domain = $vars['params']['sld'] . '.' . $vars['params']['tld'];
    logActivity("Spaceship: Domain transfer initiated for {$domain}");
});

/**
 * Hook: AfterRegistrarRenewal
 * Triggered after a domain renewal
 */
add_hook('AfterRegistrarRenewal', 1, function($vars) {
    if ($vars['params']['registrar'] !== 'spaceship') {
        return;
    }

    $domain = $vars['params']['sld'] . '.' . $vars['params']['tld'];
    logActivity("Spaceship: Domain {$domain} renewed successfully");
});

/**
 * Hook: DomainEdit
 * Triggered when domain details are edited
 */
add_hook('DomainEdit', 1, function($vars) {
    // Get domain registrar
    $domainId = $vars['domainid'];
    
    $domain = Capsule::table('tbldomains')
        ->where('id', $domainId)
        ->first();
    
    if ($domain && $domain->registrar === 'spaceship') {
        logActivity("Spaceship: Domain ID {$domainId} was edited");
    }
});

/**
 * Hook: PreRegistrarRegisterDomain
 * Triggered before domain registration - useful for validation
 */
add_hook('PreRegistrarRegisterDomain', 1, function($vars) {
    if ($vars['params']['registrar'] !== 'spaceship') {
        return;
    }

    // Perform any pre-registration validation here
    $domain = $vars['params']['sld'] . '.' . $vars['params']['tld'];

    // Example: Check if domain meets specific requirements
    // if (strlen($vars['params']['sld']) < 3) {
    //     return ['abortWithError' => 'Domain name must be at least 3 characters'];
    // }

    return [];
});

/**
 * Hook: PreRegistrarTransferDomain
 * Triggered before domain transfer - useful for validation
 */
add_hook('PreRegistrarTransferDomain', 1, function($vars) {
    if ($vars['params']['registrar'] !== 'spaceship') {
        return;
    }

    // Validate EPP code is provided
    if (empty($vars['params']['eppcode'])) {
        // Some TLDs don't require EPP code, so this is just a warning
        logActivity("Spaceship: Transfer initiated without EPP code for " . 
            $vars['params']['sld'] . '.' . $vars['params']['tld']);
    }

    return [];
});

/**
 * Hook: DomainTransferCompleted
 * Triggered when a domain transfer is completed
 */
add_hook('DomainTransferCompleted', 1, function($vars) {
    $domainId = $vars['domainId'];
    
    $domain = Capsule::table('tbldomains')
        ->where('id', $domainId)
        ->first();
    
    if ($domain && $domain->registrar === 'spaceship') {
        logActivity("Spaceship: Domain transfer completed for {$domain->domain}");
        
        // Optional: Update any custom fields or trigger additional actions
    }
});

/**
 * Hook: DomainTransferFailed
 * Triggered when a domain transfer fails
 */
add_hook('DomainTransferFailed', 1, function($vars) {
    $domainId = $vars['domainId'];
    $reason = $vars['failureReason'] ?? 'Unknown reason';
    
    $domain = Capsule::table('tbldomains')
        ->where('id', $domainId)
        ->first();
    
    if ($domain && $domain->registrar === 'spaceship') {
        logActivity("Spaceship: Domain transfer failed for {$domain->domain}. Reason: {$reason}");
    }
});

/**
 * Hook: AdminAreaPage
 * Add custom admin area functionality
 */
add_hook('AdminAreaPage', 1, function($vars) {
    // Add any admin area customizations here
    return [];
});

/**
 * Hook: ClientAreaPageDomainDetails
 * Customize the client area domain details page
 */
add_hook('ClientAreaPageDomainDetails', 1, function($vars) {
    // Get the domain
    $domainId = $vars['domainid'] ?? 0;
    
    if (!$domainId) {
        return [];
    }
    
    $domain = Capsule::table('tbldomains')
        ->where('id', $domainId)
        ->first();
    
    if ($domain && $domain->registrar === 'spaceship') {
        // Add custom template variables for Spaceship domains
        return [
            'spaceshipDomain' => true,
            'spaceshipInfo' => 'Managed by Spaceship.com',
        ];
    }
    
    return [];
});

/**
 * Hook: DailyCronJob
 * Perform daily maintenance tasks
 */
add_hook('DailyCronJob', 1, function($vars) {
    // Sync domain statuses for Spaceship domains
    $domains = Capsule::table('tbldomains')
        ->where('registrar', 'spaceship')
        ->where('status', 'Active')
        ->get();
    
    foreach ($domains as $domain) {
        // Queue domains for status sync
        // This is handled by WHMCS's built-in domain sync functionality
    }
    
    logActivity("Spaceship: Daily cron completed for " . count($domains) . " domains");
});

/**
 * Hook: AfterRegistrarRegistrationFailed
 * Triggered after a domain registration fails
 */
add_hook('AfterRegistrarRegistrationFailed', 1, function($vars) {
    if ($vars['params']['registrar'] !== 'spaceship') {
        return;
    }

    $domain = $vars['params']['sld'] . '.' . $vars['params']['tld'];
    $error = $vars['error'] ?? 'Unknown error';
    
    logActivity("Spaceship: Domain registration failed for {$domain}. Error: {$error}");
});

/**
 * Hook: AfterRegistrarRenewalFailed
 * Triggered after a domain renewal fails
 */
add_hook('AfterRegistrarRenewalFailed', 1, function($vars) {
    if ($vars['params']['registrar'] !== 'spaceship') {
        return;
    }

    $domain = $vars['params']['sld'] . '.' . $vars['params']['tld'];
    $error = $vars['error'] ?? 'Unknown error';
    
    logActivity("Spaceship: Domain renewal failed for {$domain}. Error: {$error}");
});

/**
 * Hook: AfterShoppingCartCheckout
 * Handle post-checkout actions for domain orders
 */
add_hook('AfterShoppingCartCheckout', 1, function($vars) {
    $orderId = $vars['OrderID'];
    
    // Get domain orders from this order
    $domains = Capsule::table('tbldomains')
        ->where('orderid', $orderId)
        ->where('registrar', 'spaceship')
        ->get();
    
    if ($domains->count() > 0) {
        logActivity("Spaceship: New order #{$orderId} contains " . $domains->count() . " domain(s)");
    }
});
