# Spaceship.com WHMCS Domain Registrar Module

A fully-featured WHMCS domain registrar module for [Spaceship.com](https://spaceship.com), providing complete integration with their domain registration API.

## Features

- **Domain Registration** - Register new domains with customizable privacy protection
- **Domain Transfer** - Transfer domains from other registrars with EPP code support
- **Domain Renewal** - Renew domains for 1-10 years
- **Nameserver Management** - View and update domain nameservers
- **DNS Record Management** - Full DNS management (A, AAAA, CNAME, MX, TXT, NS, SRV records)
- **WHOIS Contact Management** - View and update registrant, admin, tech, and billing contacts
- **Privacy Protection** - Enable/disable WHOIS privacy (ID Protection)
- **Domain Lock** - Lock/unlock domains for transfer protection
- **EPP Code Retrieval** - Get authorization codes for domain transfers
- **Child Nameservers** - Create, modify, and delete glue records
- **Auto-Renewal Management** - Enable/disable automatic renewal
- **Domain Sync** - Automatic synchronization of domain status and expiry dates
- **Transfer Sync** - Monitor incoming domain transfer status
- **Premium Domain Support** - Handle premium domain pricing
- **Async Operation Handling** - Full support for Spaceship's asynchronous API operations

## Requirements

- WHMCS 7.10.0 or later
- PHP 7.4 or later
- PHP cURL extension
- PHP JSON extension
- Spaceship.com API credentials

## Installation

1. **Download the Module**
   
   Download or clone this repository to your local machine.

2. **Upload Files**
   
   Upload the `spaceship` folder to your WHMCS installation:
   ```
   /path/to/whmcs/modules/registrars/spaceship/
   ```

3. **Set Permissions**
   
   Ensure proper file permissions:
   ```bash
   chmod 755 /path/to/whmcs/modules/registrars/spaceship/
   chmod 644 /path/to/whmcs/modules/registrars/spaceship/*.php
   chmod 644 /path/to/whmcs/modules/registrars/spaceship/*.json
   ```

4. **Activate the Module**
   
   - Log in to your WHMCS Admin Area
   - Navigate to **Setup > Products/Services > Domain Registrars**
   - Find "Spaceship.com Domain Registrar" and click **Activate**

5. **Configure the Module**
   
   After activation, click **Configure** and enter:
   - **API Key**: Your Spaceship API Key
   - **API Secret**: Your Spaceship API Secret
   - **Test Mode**: Enable for sandbox testing
   - **Default Privacy Protection**: Choose default privacy level
   - **Default Auto Renew**: Enable/disable auto-renewal by default

## Getting API Credentials

1. Log in to your [Spaceship.com](https://spaceship.com) account
2. Navigate to **Account Settings > API Manager**
3. Create a new API key with the following permissions:
   - `domains:read`
   - `domains:write`
   - `domains:billing`
   - `domains:transfer`
   - `contacts:read`
   - `contacts:write`
   - `dnsrecords:read`
   - `dnsrecords:write`
4. Copy the API Key and API Secret

## Module Structure

```
spaceship/
├── spaceship.php          # Main module file
├── hooks.php              # WHMCS hooks
├── whmcs.json             # Module configuration
├── logo.png               # Module logo
├── README.md              # This file
└── lib/
    └── ApiClient.php      # API client class
```

## Configuration Options

| Option | Type | Description |
|--------|------|-------------|
| API Key | Text | Your Spaceship API Key |
| API Secret | Password | Your Spaceship API Secret |
| Test Mode | Checkbox | Use sandbox API endpoint |
| Default Privacy Protection | Dropdown | Default privacy level (High/Low/Off) |
| Default Auto Renew | Checkbox | Enable auto-renewal by default |
| Debug Mode | Checkbox | Enable detailed logging |

## Supported Functions

### Core Functions
- `RegisterDomain` - Register a new domain
- `TransferDomain` - Initiate domain transfer
- `RenewDomain` - Renew domain registration

### Domain Management
- `GetNameservers` - Retrieve current nameservers
- `SaveNameservers` - Update nameservers
- `GetRegistrarLock` - Check domain lock status
- `SaveRegistrarLock` - Enable/disable domain lock
- `GetContactDetails` - Get WHOIS contact information
- `SaveContactDetails` - Update WHOIS contacts

### DNS Management
- `GetDNS` - Retrieve DNS records
- `SaveDNS` - Update DNS records

### Advanced Features
- `IDProtectToggle` - Enable/disable privacy protection
- `GetEPPCode` - Retrieve EPP/Auth code
- `RegisterNameserver` - Create child nameserver
- `ModifyNameserver` - Update child nameserver
- `DeleteNameserver` - Remove child nameserver

### Sync Functions
- `Sync` - Synchronize domain status and expiry
- `TransferSync` - Check transfer status
- `CheckAvailability` - Domain availability lookup

## Async Operations

The Spaceship API uses asynchronous operations for certain actions like domain registration and transfers. This module handles async operations automatically by:

1. Submitting the request
2. Receiving an operation ID
3. Polling for completion
4. Returning the final result

The default timeout for async operations is 120 seconds.

## Error Handling

The module provides comprehensive error handling:

- API connection errors
- Authentication failures
- Validation errors
- Rate limit exceeded
- Async operation timeouts

All errors are logged to the WHMCS Module Log for debugging.

## Logging

Enable **Debug Mode** in the module configuration to log detailed API requests and responses. Logs can be viewed at:

**Utilities > Logs > Module Log**

## Troubleshooting

### Common Issues

**"Unauthorized - Please check your API credentials"**
- Verify your API Key and Secret are correct
- Ensure the API key has the required permissions

**"Rate limit exceeded"**
- Wait a few minutes before retrying
- Consider implementing request batching

**"Domain not found"**
- Verify the domain is in your Spaceship account
- Check for typos in the domain name

**Async Operation Timeout**
- Increase timeout value if needed
- Check Spaceship status page for API issues

### Debug Steps

1. Enable Debug Mode in module settings
2. Attempt the failing operation
3. Check Module Log for detailed API responses
4. Review error messages for specific issues

## API Reference

This module integrates with the Spaceship API v1. For complete API documentation, visit:

- [Spaceship API Documentation](https://developers.spaceship.com)
- [API Reference](https://spaceship.dev/api)

## Support

For issues related to:

- **This Module**: Open an issue on GitHub
- **WHMCS**: Contact [WHMCS Support](https://whmcs.com/support)
- **Spaceship API**: Contact [Spaceship Support](https://spaceship.com/support)

## Changelog

### Version 1.0.0 (2026-01-18)
- Initial release
- Full domain registration, transfer, and renewal support
- Complete DNS management
- WHOIS privacy protection
- Child nameserver management
- Domain sync functionality
- Async operation handling

## License

This module is released under the MIT License. See LICENSE file for details.

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## Disclaimer

This module is provided as-is without warranty. Always test in a staging environment before deploying to production.

---

**Built for [Spaceship.com](https://spaceship.com) 🚀**
